extends SceneTree

func _initialize() -> void:
	create_timer(40).timeout.connect(func():
		push_error("CHARACTERS FAIL: timeout")
		quit(1))
	call_deferred("_run")

func _expect(ok: bool, message: String) -> bool:
	if not ok:
		push_error("CHARACTERS FAIL: " + message)
		quit(1)
	return ok

func _run() -> void:
	var characters = root.get_node("Characters")
	var state = root.get_node("GameState")
	# Character preferences must never alter the existing high-score file.
	state.high_score = 12345
	state.save_high_score()
	var scores_before := FileAccess.get_file_as_bytes("user://highscore.cfg")
	if not _expect(characters.select("suit"), "select and persist second character"): return
	characters.selected_id = characters.DEFAULT_ID
	characters.load_selection()
	if not _expect(characters.selected_id == "suit", "selection survives reload"): return
	if not _expect(not characters.select("unknown") and characters.selected_id == "suit", "invalid selection is rejected"): return
	var game = load("res://scenes/campus.tscn").instantiate()
	root.add_child(game)
	while game.loading_screen.visible:
		await process_frame
	if not _expect(game.player.character_id == "suit", "game uses saved character"): return
	if not _expect(game.character_button.visible, "campus selection entry is visible"): return
	game._open_characters()
	game.character_panel.show_candidate("duoge")
	game.character_panel.close()
	if not _expect(characters.selected_id == "suit" and game.player.character_id == "suit", "cancel preview leaves selection unchanged"): return
	for id in ["duoge", "suit", "duoge", "suit"]:
		game._open_characters()
		game.character_panel.show_candidate(id)
		game.character_panel.use_requested.emit(id)
		if not _expect(game.player.character_id == id and characters.selected_id == id, "apply " + id): return
		if not _expect(not game.character_panel.visible and game.character_panel._preview == null, "closed preview releases model"): return
		if not _expect(game.player._animation_names.size() == 4 and game.player._current_clip == "Idle", "all four clips ready"): return
		if not _expect(game.player._visual.get_child_count() == 1, "old model released on switch"): return
		for child in game.player.get_children():
			# The separate, hidden pickup indicator is not the removed always-on halo.
			if child is MeshInstance3D and child.mesh is TorusMesh and child.visible:
				_expect(false, "persistent foot halo must be absent")
				return
		if not _expect(is_equal_approx(game.player._shape.height, 1.8), "same standing collision"): return
	if not _expect(FileAccess.get_file_as_bytes("user://highscore.cfg") == scores_before, "selection must leave score file byte-identical"): return
	game._start_game()
	game._open_characters()
	game._use_character("duoge")
	if not _expect(not game.character_panel.visible and game.player.character_id == "suit", "cannot switch during a run"): return
	game.player.die()
	await create_timer(1.6, true, false, true).timeout
	game._show_start()
	if not _expect(game.player.character_id == "suit" and game.player._current_clip == "Idle", "death/home keeps chosen character"): return
	# A run may add a campus score, while the pre-existing run record survives.
	game.queue_free()
	await process_frame
	var saved := ConfigFile.new()
	saved.load("user://highscore.cfg")
	if not _expect(int(saved.get_value("run", "high_score", 0)) == 12345, "existing record preserved"): return
	# Unknown/future IDs fall back safely without deleting the preference file.
	var pref := ConfigFile.new()
	pref.set_value("selection", "character_id", "unknown")
	pref.save(characters.SAVE_PATH)
	characters.load_selection()
	if not _expect(characters.selected_id == characters.DEFAULT_ID, "unknown saved ID falls back to original"): return
	print("CHARACTERS OK: persistence, both models, cancel/apply, gameplay guard, collision, no halo, death/home and score preservation")
	quit()
