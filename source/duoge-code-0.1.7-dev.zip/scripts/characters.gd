extends Node

signal changed

const DEFAULT_ID := "duoge"
const SAVE_PATH := "user://characters.cfg"
const ROSTER := {
	"duoge": {"name": "舵哥", "model": "res://assets/models/teacher/teacher_runner.glb"},
	"suit": {"name": "战衣角色", "model": "res://assets/models/characters/suit_runner.glb"},
}

var selected_id := DEFAULT_ID

func _ready() -> void:
	load_selection()

func load_selection() -> void:
	selected_id = DEFAULT_ID
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) == OK:
		var saved: String = str(config.get_value("selection", "character_id", DEFAULT_ID))
		if ROSTER.has(saved):
			selected_id = saved

func select(id: String) -> bool:
	if not ROSTER.has(id):
		return false
	var config := ConfigFile.new()
	config.load(SAVE_PATH)
	config.set_value("selection", "character_id", id)
	if config.save(SAVE_PATH) != OK:
		return false
	selected_id = id
	changed.emit()
	return true

func display_name(id: String) -> String:
	return str(ROSTER.get(id, ROSTER[DEFAULT_ID])["name"])
