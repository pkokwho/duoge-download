extends "res://scripts/main.gd"

@export var preview: = true
const ZONES: = ["校门大道", "街角便利街", "校园公交站"]
const GOAL_COINS: = 120
const MAGNET_SECONDS: = 4.0
var magnet_seconds: = 0.0
var magnets_claimed: = 0
var goals: Array[bool] = [false, false, false]
var sample_complete: = false
var sample_start_button: Button
var _goal_label: Label
var _magnet_label: Label
var _best_label: Label
var _toast_label: Label
var _toast_panel: Panel
var _toast_seconds: = 0.0
var _scan_seconds: = 0.0
var _magnet_ring: MeshInstance3D
var _contact_shadow: MeshInstance3D

func _ready() -> void :
	GameState.set_mode("campus_sample_p2")
	super._ready()
	cam.near = 0.2
	cam.far = 140.0
	(track as CampusTrack).sample_finished.connect(_finish_sample)
	player.get_node("Hurtbox").area_entered.connect(_pickup_entered)
	for light in player.find_children("*", "OmniLight3D", true, false): light.light_energy = 0.15
	for mesh in player._visual.find_children("*", "MeshInstance3D", true, false): mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_contact_shadow = MeshInstance3D.new()
	var quad: = QuadMesh.new()
	quad.size = Vector2(1.25, 1.1)
	_contact_shadow.mesh = quad
	var shadow: = ShaderMaterial.new()
	shadow.shader = load("res://shaders/campus_shadow.gdshader")
	_contact_shadow.material_override = shadow
	_contact_shadow.rotation.x = - PI / 2
	_contact_shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_contact_shadow)
	_contact_shadow.position.y = 0.034
	_magnet_ring = MeshInstance3D.new()
	var ring: = TorusMesh.new()
	ring.inner_radius = 0.69
	ring.outer_radius = 0.74
	ring.rings = 24
	ring.ring_segments = 8
	_magnet_ring.mesh = ring
	var material: = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color("66e5df")
	_magnet_ring.material_override = material
	_magnet_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	player.add_child(_magnet_ring)
	_magnet_ring.position.y = 0.07
	_magnet_ring.hide()

func _make_track() -> TrackManager: return CampusTrack.new()

func _update_button_status() -> void :
	super._update_button_status()
	if preview and OS.has_feature("web") and settings_version_label:
		settings_version_label.text = "校园样段 P2 · 网页试玩"

func _build_environment() -> void :
	var world: = WorldEnvironment.new()
	var env: = Environment.new()
	var sky: = Sky.new()
	var sky_material: = ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("8fc3d6")
	sky_material.sky_horizon_color = Color("d9e9df")
	sky_material.ground_horizon_color = Color("c0d4b0")
	sky_material.ground_bottom_color = Color("90af87")
	sky_material.sun_angle_max = 3.0
	sky.sky_material = sky_material
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("c7dce4")
	env.ambient_light_energy = 0.5
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	world.environment = env
	add_child(world)
	var sun: = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_color = Color("fff0d8")
	sun.light_energy = 0.75
	sun.shadow_enabled = false
	sun.directional_shadow_max_distance = 18
	add_child(sun)

func _build_skyline() -> void :
	for spec in [[-15.0, -78.0, 0.9], [14.0, -83.0, 1.0], [-23.0, -85.0, 1.4], [23.0, -89.0, 1.2]]:
		var node: = CampusModels.make("school")
		add_child(node)
		node.position = Vector3(spec[0], - 0.1, spec[1])
		node.scale = Vector3.ONE * spec[2]

func _build_ui() -> void :
	super._build_ui()

	for child in start_screen.get_children(): child.hide()
	settings_button.show()
	_panel(start_screen, 0.04, 0.025, 0.96, 0.238, Color(NAVY, 0.94), 18)
	var eyebrow: = _label("马眼工作室  /  单路线挑战" + (" P2" if preview else ""), 18, WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_place(eyebrow, start_screen, 0.05, 0.035, 0.65, 0.08)
	_place(_label("舵哥 · 校园漫游", 53, WHITE, HORIZONTAL_ALIGNMENT_LEFT), start_screen, 0.05, 0.11, 0.96, 0.18)
	_place(_label("校门大道 → 便利街 → 公交站", 24, GOLD, HORIZONTAL_ALIGNMENT_LEFT), start_screen, 0.055, 0.185, 0.96, 0.23)
	var card: = _panel(start_screen, 0.04, 0.77, 0.96, 0.982, Color(NAVY, 0.96), 22, Color(GOLD, 0.4))
	_place(_label("75 秒挑战 · 收集 %d 金币 · 体验磁铁" % GOAL_COINS, 23, WHITE), card, 0.04, 0.05, 0.96, 0.23)
	_best_label = _label("", 19, Color(WHITE, 0.72))
	_place(_best_label, card, 0.04, 0.24, 0.96, 0.38)
	sample_start_button = _button("开始校园挑战   →", 37, NAVY, GOLD, false)
	_place(sample_start_button, card, 0.04, 0.44, 0.96, 0.77)
	sample_start_button.pressed.connect(_start_game)
	_place(_label("左右换道 · 上滑跳跃 · 下滑滑铲", 19, Color(WHITE, 0.8)), card, 0.04, 0.8, 0.96, 0.98)
	settings_button.move_to_front()
	character_button.show()
	_place_existing_character_button()
	var speed_card: Control = speed_label.get_parent()
	for number in [score_label, coin_label]:
		var panel: Control = number.get_parent()
		panel.anchor_top = 0.022
		panel.anchor_bottom = 0.087
		number.add_theme_font_size_override("font_size", 43)
	speed_card.anchor_top = 0.099
	speed_card.anchor_right = 0.72
	speed_card.anchor_bottom = 0.138
	speed_label.add_theme_font_size_override("font_size", 24)
	var magnet_card: = _panel(hud, 0.74, 0.099, 0.975, 0.138, Color(NAVY, 0.92), 14)
	_magnet_label = _label("磁铁待拾取", 22, Color("85e0d1"))
	_place(_magnet_label, magnet_card, 0.02, 0, 0.98, 1)
	var goal_card: = _panel(hud, 0.025, 0.148, 0.975, 0.185, Color(NAVY, 0.9), 12)
	_goal_label = _label("", 24, WHITE)
	_place(_goal_label, goal_card, 0.02, 0, 0.98, 1)
	_toast_panel = _panel(hud, 0.1, 0.196, 0.9, 0.235, Color(GOLD, 0.96), 12)
	_toast_label = _label("", 23, NAVY)
	_place(_toast_label, _toast_panel, 0.02, 0, 0.98, 1)
	_toast_panel.hide()
	menu_version_label.text = "校园样段 P2" if preview else "v" + Updates.installed_name
	var footer: = _label("校园样段 P2 · 每次试跑 75 秒" if preview else "校园挑战 · 75 秒 · v" + Updates.installed_name, 19, Color(WHITE, 0.8))
	_place(footer, over_screen, 0.08, 0.125, 0.92, 0.17)

func _place_existing_character_button() -> void:
	character_button.anchor_left = 0.04
	character_button.anchor_right = 0.63
	character_button.anchor_top = 0.697
	character_button.anchor_bottom = 0.758
	character_button.move_to_front()

func _show_start() -> void :
	super._show_start()
	track.reset()
	track.visible = true
	player.visible = true
	player.position.y = 0.02
	_update_camera(0.0, true)
	_best_label.text = "样段最佳 %s 分 · 与无尽模式分开记录" % _format_score(GameState.high_score) if preview else "本关最佳 %s 分 · v%s" % [_format_score(GameState.high_score), Updates.installed_name]
	if _magnet_ring: _magnet_ring.hide()
	if _contact_shadow: _contact_shadow.position.x = 0

func _start_game() -> void :
	magnet_seconds = 0
	magnets_claimed = 0
	goals = [false, false, false]
	sample_complete = false
	_scan_seconds = 0
	super._start_game()
	hint_panel.hide()
	if _magnet_ring: _magnet_ring.hide()
	_toast("每段一条金币路线 · 上跳下滑追金币", 3.5)

func _process(delta: float) -> void :
	super._process(delta)
	if not playing or _goal_label == null: return
	_contact_shadow.position.x = player.position.x
	_contact_shadow.scale = Vector3.ONE * clampf(1.0 - player.position.y * 0.1, 0.65, 1.0)
	var sample: = track as CampusTrack
	var remain: = maxf(0, CampusTrack.SAMPLE_SECONDS - sample.elapsed())
	speed_label.text = "%s  ·  剩余 %02d 秒" % [ZONES[sample.zone()], ceili(remain)]
	_goal_label.text = "金币 %d/%d   ·   磁铁 %d/1   ·   目标 %d/3" % [GameState.coins, GOAL_COINS, magnets_claimed, _goal_count()]
	magnet_seconds = maxf(0, magnet_seconds - delta)
	_magnet_label.text = "磁铁 %.1fs" % magnet_seconds if magnet_seconds > 0 else "磁铁待拾取"
	if _magnet_ring:
		_magnet_ring.visible = magnet_seconds > 0
		_magnet_ring.scale = Vector3.ONE * (1.0 + sin(Time.get_ticks_msec() * 0.006) * 0.04)
	_scan_seconds -= delta
	if magnet_seconds > 0 and _scan_seconds <= 0:
		_scan_seconds = 0.08
		for coin in get_tree().get_nodes_in_group("coin"):
			if coin.has_method("attract_to") and coin.global_position.z > -8.0 and coin.global_position.z < 3.0 and coin.global_position.distance_squared_to(player.global_position) < 64:
				coin.attract_to(player)
	if _toast_seconds > 0:
		_toast_seconds -= delta
		if _toast_seconds <= 0: _toast_panel.hide()

func _pickup_entered(area: Area3D) -> void :
	if playing and area.is_in_group("campus_magnet") and area.claim():
		magnets_claimed += 1
		magnet_seconds = MAGNET_SECONDS
		Sfx.play("coin", -3.0)
		_toast("磁铁启动 · 4 秒吸取附近金币")
		_check_goals()

func _on_coins_changed(value: int) -> void :
	super._on_coins_changed(value)
	_check_goals()

func _goal_count() -> int:
	var count: = 0
	for value in goals:
		if value: count += 1
	return count

func _check_goals() -> void :
	if not playing: return
	if GameState.coins >= GOAL_COINS and not goals[1]:
		goals[1] = true
		GameState.add_bonus(100)
		_toast("目标达成 · 收集 %d 金币  +100" % GOAL_COINS)
	if magnets_claimed >= 1 and not goals[2]:
		goals[2] = true
		GameState.add_bonus(100)
		_toast("目标达成 · 使用磁铁  +100")

func _toast(text: String, seconds: = 2.4) -> void :
	_toast_label.text = text
	_toast_panel.show()
	_toast_seconds = seconds

func _finish_sample() -> void :
	if not playing: return
	sample_complete = true
	goals[0] = true
	GameState.add_bonus(150)
	speed_label.text = "校园公交站 · 75 秒试跑完成"
	_goal_label.text = "金币 %d/%d   ·   磁铁 %d/1   ·   目标 %d/3" % [GameState.coins, GOAL_COINS, magnets_claimed, _goal_count()]
	playing = false
	player.set_physics_process(false)
	track.set_physics_process(false)
	GameState.end_run()

func _on_player_died() -> void :
	super._on_player_died()
	track.set_physics_process(false)

func _on_game_over(final_score: int, final_coins: int, new_record: bool) -> void :
	await super._on_game_over(final_score, final_coins, new_record)
	over_title_label.text = "试跑完成！" if sample_complete else "再试一次！"
	record_label.text = "完成目标 %d/3 · 金币 %d/%d" % [_goal_count(), final_coins, GOAL_COINS]
	record_label.show()
	if _magnet_ring: _magnet_ring.hide()
