extends Control

signal use_requested(id: String)

var candidate_id := ""
var _game
var _world: Node3D
var _viewport: SubViewport
var _preview: Node3D
var _tabs: Dictionary = {}
var _status: Label
var _apply: Button

func setup(game) -> void:
	_game = game
	theme = game.ui_theme
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	game._color(self, Color(0.02, 0.06, 0.1, 0.88), 0, 0, 1, 1)
	var card: Panel = game._panel(self, 0.065, 0.09, 0.935, 0.92, Color("102941"), 22, game.GOLD)
	game._place(game._label("选择角色", 36, game.GOLD), card, 0.05, 0.025, 0.95, 0.10)
	var index := 0
	for id in Characters.ROSTER:
		var button: Button = game._button(Characters.display_name(id), 27, game.WHITE, Color("1b3854"), false)
		button.toggle_mode = true
		game._place(button, card, 0.06 + index * 0.46, 0.12, 0.48 + index * 0.46, 0.205)
		button.pressed.connect(show_candidate.bind(id))
		_tabs[id] = button
		index += 1
	var container := SubViewportContainer.new()
	container.stretch = true
	container.stretch_shrink = 2
	container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	game._place(container, card, 0.06, 0.22, 0.94, 0.72)
	_viewport = SubViewport.new()
	_viewport.own_world_3d = true
	_viewport.transparent_bg = true
	_viewport.handle_input_locally = false
	container.add_child(_viewport)
	_world = Node3D.new()
	_viewport.add_child(_world)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color("e4efff")
	environment.environment.ambient_light_energy = 0.65
	_world.add_child(environment)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-30, -25, 0)
	light.light_energy = 0.9
	_world.add_child(light)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 2.1
	camera.position = Vector3(0, 1.05, 3.5)
	_world.add_child(camera)
	camera.look_at(Vector3(0, 0.88, 0))
	camera.make_current()
	_status = game._label("两位角色能力相同", 22, game.WHITE)
	game._place(_status, card, 0.04, 0.73, 0.96, 0.80)
	_apply = game._button("使用这个角色", 30, game.NAVY, game.GOLD, false)
	game._place(_apply, card, 0.06, 0.82, 0.94, 0.91)
	_apply.pressed.connect(func(): use_requested.emit(candidate_id))
	var back: Button = game._button("返回", 25, game.WHITE, Color("1b3854"), false)
	game._place(back, card, 0.25, 0.925, 0.75, 0.987)
	back.pressed.connect(close)
	close()

func open() -> void:
	show()
	_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	show_candidate(Characters.selected_id)

func show_candidate(id: String) -> void:
	if not Characters.ROSTER.has(id):
		return
	if _preview:
		_preview.free()
		_preview = null
	var packed := load(str(Characters.ROSTER[id]["model"])) as PackedScene
	if packed == null:
		_status.text = "角色加载失败，请返回重试"
		_apply.disabled = true
		return
	_preview = packed.instantiate()
	_world.add_child(_preview)
	for mesh in _preview.find_children("*", "MeshInstance3D", true, false):
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for player in _preview.find_children("*", "AnimationPlayer", true, false):
		for clip in player.get_animation_list():
			if clip == "Idle" or clip.ends_with("/Idle") or clip.ends_with("|Idle"):
				player.get_animation(clip).loop_mode = Animation.LOOP_LINEAR
				player.play(clip)
	candidate_id = id
	_apply.disabled = false
	_status.text = "当前使用：%s" % Characters.display_name(id) if id == Characters.selected_id else "两位角色能力相同"
	for key in _tabs:
		_tabs[key].set_pressed_no_signal(key == id)
		_tabs[key].modulate = Color("ffd06a") if key == id else Color.WHITE

func show_error(message: String) -> void:
	_status.text = message

func close() -> void:
	hide()
	if _viewport:
		_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	if _preview:
		_preview.free()
		_preview = null
