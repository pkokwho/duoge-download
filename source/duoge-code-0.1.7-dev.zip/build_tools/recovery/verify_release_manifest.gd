extends SceneTree
func _initialize() -> void:
 call_deferred("_run")
func _check(ok: bool, message: String) -> bool:
 if not ok:
  push_error(message)
  quit(1)
 return ok
func _run() -> void:
 var service = load("res://scripts/app_updates.gd")
 if not _check(service.target_package_name() == "org.duoge.parkour.standalone", "Actual packaged client must target independent update channel"): return
 var manifest = JSON.parse_string(FileAccess.get_file_as_string(OS.get_environment("DUOGE_RELEASE_MANIFEST")))
 var result: Dictionary = service.validate_manifest(manifest, service.VERSION_CODE, 35)
 if not _check(not result.has("error"), "Actual release manifest rejected"): return
 var details: Dictionary = result.get("announcement", {}) if service.VERSION_CODE == 7 else result
 if not _check(details.get("version_code") == 7 and str(details.get("notes", "")).contains("变白"), "Missing real color-fix announcement"): return
 if not _check(details.get("sha256") == "047d88d122231a8538223dc107b1e0d978bfb80da389aae797fec4c995c506e4", "Wrong released APK hash"): return
 if not _check(result.get("current", false) == (service.VERSION_CODE == 7), "Wrong upgrade/current result"): return
 if not _check(service.validate_manifest(manifest, 8, 35).get("current", false), "Older release must not downgrade client"): return
 if not _check(service.validate_manifest(manifest, service.VERSION_CODE, 28).get("unsupported", false), "Android SDK floor must be enforced"): return
 manifest.package_name = "org.duoge.parkour"
 if not _check(service.validate_manifest(manifest, service.VERSION_CODE, 35).has("error"), "Wrong package must be rejected"): return
 print("LIVE RELEASE OK: actual packaged client code ", service.VERSION_CODE, "; correct update/current announcement, hash, SDK and package checks")
 quit()
