extends SceneTree

var game
var output: String

func _initialize() -> void:
	call_deferred("_run")

func _capture(name: String) -> void:
	for frame in range(8):
		await RenderingServer.frame_post_draw
	var error := root.get_texture().get_image().save_png(output.path_join(name + ".png"))
	if error != OK:
		push_error("CHARACTER RENDER FAIL: " + name)
		quit(1)

func _run() -> void:
	output = OS.get_environment("DUOGE_CHARACTER_SHOTS")
	assert(not output.is_empty())
	DirAccess.make_dir_recursive_absolute(output)
	var characters = root.get_node("Characters")
	assert(characters.select("duoge"))
	game = load("res://scenes/campus.tscn").instantiate()
	root.add_child(game)
	while game.loading_screen.visible:
		await process_frame
	await _capture("home-duoge")
	game._open_characters()
	await _capture("picker-duoge")
	game.character_panel.show_candidate("suit")
	await _capture("picker-suit")
	game.character_panel.use_requested.emit("suit")
	assert(game.player.character_id == "suit")
	await _capture("home-suit")
	game._start_game()
	game.player.get_node("Hurtbox").monitoring = false
	await create_timer(1).timeout
	game.track.set_physics_process(false)
	game.player.set_physics_process(false)
	game.player.set_process(false)
	game.set_process(false)
	for clip in ["Run", "Jump", "Slide"]:
		var player: AnimationPlayer = game.player._animation_player
		player.play(game.player._animation_names[clip])
		player.seek(0.33 if clip == "Jump" else 0.18, true)
		player.pause()
		await _capture("suit-" + clip.to_lower())
	game.player.die()
	await create_timer(1.6, true, false, true).timeout
	game._show_start()
	game._use_character("duoge")
	game._start_game()
	await create_timer(1).timeout
	await _capture("duoge-no-halo")
	print("CHARACTER RENDER OK: both pickers, both home models, Run/Jump/Slide and original without halo")
	quit()
