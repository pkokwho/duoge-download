#!/usr/bin/env python3
"""Sign a prepared APK only with the original game's signing identity."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

from rebuild_unsigned import SIGNER_SHA256, VERSION_CODE, VERSION_NAME, sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", type=Path, required=True)
    parser.add_argument("--keystore", type=Path, required=True)
    parser.add_argument("--alias", default="androiddebugkey")
    parser.add_argument("--build-tools", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not args.apk.is_file() or not args.keystore.is_file():
        parser.error("The APK and original keystore files must exist")
    if args.output.resolve() == args.apk.resolve():
        parser.error("The signed output must be a separate file")
    for name in ("DUOGE_KEYSTORE_PASSWORD", "DUOGE_KEY_PASSWORD"):
        if not os.environ.get(name):
            parser.error("Set " + name + " securely in the process environment; do not store passwords in the repository")
    badging = subprocess.run([str(args.build_tools / "aapt"), "dump", "badging", str(args.apk)],
                            check=True, capture_output=True, text=True).stdout
    if f"name='org.duoge.parkour' versionCode='{VERSION_CODE}' versionName='{VERSION_NAME}'" not in badging:
        parser.error("The input is not the prepared " + VERSION_NAME + " game APK")
    # Export the public certificate only. Reject another key before signing anything.
    with tempfile.TemporaryDirectory() as folder:
        cert = Path(folder) / "public-cert.der"
        subprocess.run(["keytool", "-exportcert", "-keystore", str(args.keystore), "-alias", args.alias,
                        "-storepass:env", "DUOGE_KEYSTORE_PASSWORD", "-file", str(cert)], check=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if sha256(cert) != SIGNER_SHA256:
            parser.error("This keystore does not match the installed game's signer; refusing to create an incompatible update")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    signer = args.build_tools / "apksigner"
    subprocess.run([str(signer), "sign", "--ks", str(args.keystore), "--ks-key-alias", args.alias,
                    "--ks-pass", "env:DUOGE_KEYSTORE_PASSWORD", "--key-pass", "env:DUOGE_KEY_PASSWORD",
                    "--out", str(args.output), str(args.apk)], check=True)
    report = subprocess.run([str(signer), "verify", "--print-certs", str(args.output)],
                            check=True, capture_output=True, text=True).stdout
    if "certificate SHA-256 digest: " + SIGNER_SHA256 not in report:
        raise ValueError("Signed APK certificate verification failed")
    subprocess.run([str(args.build_tools / "zipalign"), "-c", "-P", "16", "4", str(args.output)], check=True)
    print("SIGNED with original identity:", args.output)
    print("SHA-256:", sha256(args.output))
    print("Device installation and update-manifest publication remain separate steps.")


if __name__ == "__main__":
    main()
