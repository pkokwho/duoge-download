#!/usr/bin/env python3
"""Sign the independent app with a retained private key; never replace an existing identity."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

from rebuild_unsigned import SIGNER_SHA256, STANDALONE_PACKAGE, VERSION_CODE, VERSION_NAME, run, sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", type=Path, required=True)
    parser.add_argument("--signing-dir", type=Path, required=True)
    parser.add_argument("--certificate-pin", type=Path, required=True, help="Non-secret SHA256 pin; safe to retain in Git")
    parser.add_argument("--build-tools", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.signing_dir.resolve().is_relative_to(Path(__file__).resolve().parents[2]):
        parser.error("Private signing files must stay outside the repository")
    badging = run([args.build_tools / "aapt", "dump", "badging", args.apk])
    if f"name='{STANDALONE_PACKAGE}' versionCode='{VERSION_CODE}' versionName='{VERSION_NAME}'" not in badging:
        parser.error("Only the independent app can use this new signing identity")
    os.umask(0o077)
    args.signing_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(args.signing_dir, 0o700)
    private = args.signing_dir / "private.pk8"
    cert = args.signing_dir / "certificate.pem"
    der = args.signing_dir / "certificate.der"
    files = [private, cert, der]
    if not all(p.is_file() for p in files):
        if any(p.exists() for p in files) or args.certificate_pin.exists():
            parser.error("Existing signing identity is incomplete; restore its backup instead of creating a replacement")
        with tempfile.TemporaryDirectory(dir=args.signing_dir) as temporary:
            work = Path(temporary)
            subprocess.run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:3072",
                            "-out", str(work / "private.pem"), "-quiet"], check=True)
            run(["openssl", "req", "-new", "-x509", "-key", work / "private.pem", "-out", work / "certificate.pem",
                 "-days", "10000", "-subj", "/CN=Duoge Parkour Independent/O=MaYan Studio", "-sha256"])
            run(["openssl", "pkcs8", "-topk8", "-nocrypt", "-in", work / "private.pem", "-outform", "DER", "-out", work / "private.pk8"])
            run(["openssl", "x509", "-in", work / "certificate.pem", "-outform", "DER", "-out", work / "certificate.der"])
            for target in files:
                shutil.copyfile(work / target.name, target)
                os.chmod(target, 0o600)
    fingerprint = sha256(der)
    if fingerprint == SIGNER_SHA256:
        parser.error("The independent identity must not be confused with the old game's signer")
    if args.certificate_pin.exists() and args.certificate_pin.read_text().strip() != fingerprint:
        parser.error("Signing identity differs from the pinned certificate")
    key_public = run(["openssl", "pkey", "-inform", "DER", "-in", private, "-pubout"])
    cert_public = run(["openssl", "x509", "-in", cert, "-pubkey", "-noout"])
    if key_public.strip() != cert_public.strip():
        parser.error("Private key and public certificate do not match")
    args.certificate_pin.parent.mkdir(parents=True, exist_ok=True)
    args.certificate_pin.write_text(fingerprint + "\n")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    run([args.build_tools / "apksigner", "sign", "--key", private, "--cert", cert, "--out", args.output, args.apk])
    report = run([args.build_tools / "apksigner", "verify", "--verbose", "--print-certs", args.output])
    if "certificate SHA-256 digest: " + fingerprint not in report:
        raise ValueError("Signed APK certificate verification failed")
    run([args.build_tools / "zipalign", "-c", "-P", "16", "4", args.output])
    instructions = (
        "PRIVATE SIGNING BACKUP — do not upload to a public repository or download website.\n"
        f"Application: {STANDALONE_PACKAGE}\nCertificate SHA256: {fingerprint}\n"
        "Keep this entire backup in private storage. Future updates must reuse private.pk8 and certificate.pem.\n"
        "This key belongs to the independent new app. It cannot update the original app.\n"
        "The PKCS8 private key is not password encrypted; protect the backup as a private credential.\n"
    )
    (args.signing_dir / "README.txt").write_text(instructions)
    backup = args.signing_dir.parent / "duoge-standalone-signing-backup.zip"
    with zipfile.ZipFile(backup, "w", compression=zipfile.ZIP_DEFLATED) as output:
        for path in files + [args.signing_dir / "README.txt"]:
            output.write(path, path.name)
    os.chmod(backup, 0o600)
    print("SIGNED independent app:", args.output)
    print("Certificate SHA256:", fingerprint)
    print("APK SHA256:", sha256(args.output))
    print("Private backup retained outside repository:", backup)


if __name__ == "__main__":
    main()
