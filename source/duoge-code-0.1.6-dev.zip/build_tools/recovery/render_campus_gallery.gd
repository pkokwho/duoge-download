extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var stage := Node3D.new()
	root.add_child(stage)
	var world := WorldEnvironment.new()
	world.environment = Environment.new()
	world.environment.background_mode = Environment.BG_COLOR
	world.environment.background_color = Color("152537")
	stage.add_child(world)
	var models = load("res://scripts/campus_models.gd")
	var kinds := ["school", "gate", "store", "cafe", "bus", "bus_stop", "tree", "barrier", "slide", "parcel", "bench", "books", "coin", "magnet"]
	for i in range(kinds.size()):
		var model: Node3D = models.make(kinds[i])
		stage.add_child(model)
		var bounds := AABB()
		var first := true
		for mesh in model.find_children("*", "MeshInstance3D", true, false):
			mesh.lod_bias = 1000.0
			var relative: Transform3D = model.global_transform.affine_inverse() * mesh.global_transform
			var box: AABB = relative * mesh.get_aabb()
			bounds = box if first else bounds.merge(box)
			first = false
		assert(not first)
		var scale_factor := 2.4 / maxf(bounds.size.x, maxf(bounds.size.y, bounds.size.z))
		var cell := Vector3((i % 7 - 3) * 3.3, 0, floori(float(i) / 7.0) * 7.0 - 3.5)
		model.scale *= scale_factor
		model.position = cell - bounds.get_center() * scale_factor
		var label := Label3D.new()
		label.text = kinds[i]
		label.font_size = 48
		label.pixel_size = 0.007
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.position = cell + Vector3(0, -1.65, 0)
		stage.add_child(label)
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 14.5
	camera.position = Vector3(0, 18, 24)
	stage.add_child(camera)
	camera.look_at(Vector3.ZERO)
	camera.make_current()
	for frame in range(8):
		await RenderingServer.frame_post_draw
	var output := OS.get_environment("DUOGE_RENDER_OUTPUT")
	assert(not output.is_empty())
	assert(root.get_texture().get_image().save_png(output) == OK)
	print("CAMPUS GALLERY RENDERED: all 14 original-color models")
	quit()
