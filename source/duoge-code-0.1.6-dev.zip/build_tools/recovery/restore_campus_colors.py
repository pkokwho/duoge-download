#!/usr/bin/env python3
"""Restore original APK vertex colors only after byte-identical vertex alignment."""
import argparse
import hashlib
import json
from pathlib import Path
import struct


def restore(path, reference):
    original_file = path.read_bytes()
    magic, version, size = struct.unpack_from("<III", original_file)
    if magic != 0x46546c67 or version != 2 or size != len(original_file):
        raise ValueError("Invalid GLB: " + str(path))
    length, kind = struct.unpack_from("<II", original_file, 12)
    if kind != 0x4e4f534a:
        raise ValueError("Missing GLB JSON")
    document = json.loads(original_file[20:20 + length])
    bin_header = 20 + length
    bin_length, kind = struct.unpack_from("<II", original_file, bin_header)
    if kind != 0x004e4942:
        raise ValueError("Missing GLB binary buffer")
    binary = original_file[bin_header + 8:bin_header + 8 + bin_length]
    primitives = [p for mesh in document["meshes"] for p in mesh["primitives"]]
    if len(primitives) != 1:
        raise ValueError("Expected the one original campus mesh surface")
    primitive = primitives[0]
    accessor = document["accessors"][primitive["attributes"]["POSITION"]]
    view = document["bufferViews"][accessor["bufferView"]]
    if accessor["componentType"] != 5126 or accessor["type"] != "VEC3":
        raise ValueError("Unexpected vertex encoding")
    offset = view.get("byteOffset", 0) + accessor.get("byteOffset", 0)
    stride = view.get("byteStride", 12)
    positions = b"".join(binary[offset + i * stride:offset + i * stride + 12] for i in range(accessor["count"]))
    prefix = reference / (path.stem + "-0")
    expected_positions = prefix.with_suffix(".positions.bin").read_bytes()
    colors = prefix.with_suffix(".colors.bin").read_bytes()
    if positions != expected_positions or len(colors) != accessor["count"] * 16:
        raise ValueError("Original vertex order/count does not match; refusing to guess colors")
    record = {"vertices": accessor["count"], "positions_sha256": hashlib.sha256(positions).hexdigest(),
              "colors_sha256": hashlib.sha256(colors).hexdigest(), "original_binary_sha256": hashlib.sha256(binary).hexdigest(),
              "original_binary_length": len(binary)}
    indices = [v[0] for v in struct.iter_unpack("<i", prefix.with_suffix(".indices.bin").read_bytes())]
    if not indices:
        indices = list(range(accessor["count"]))
    vertices = [(positions[i * 12:i * 12 + 12] + colors[i * 16:i * 16 + 16]).hex() for i in range(accessor["count"])]
    faces = []
    for i in range(0, len(indices), 3):
        a, b, c = (vertices[v] for v in indices[i:i + 3])
        faces.append(min(a + b + c, b + c + a, c + a + b))
    record["colored_triangles_sha256"] = hashlib.sha256("".join(sorted(faces)).encode("ascii")).hexdigest()
    if "COLOR_0" in primitive["attributes"]:
        raise ValueError("Vertex colors already exist; refusing to replace them")
    view_index = len(document["bufferViews"])
    document["bufferViews"].append({"buffer": 0, "byteOffset": len(binary), "byteLength": len(colors), "target": 34962})
    color_index = len(document["accessors"])
    document["accessors"].append({"bufferView": view_index, "componentType": 5126, "count": accessor["count"], "type": "VEC4"})
    primitive["attributes"]["COLOR_0"] = color_index
    restored_binary = binary + colors
    document["buffers"][0]["byteLength"] = len(restored_binary)
    encoded = json.dumps(document, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    encoded += b" " * (-len(encoded) % 4)
    result = (struct.pack("<III", magic, version, 12 + 8 + len(encoded) + 8 + len(restored_binary)) +
              struct.pack("<II", len(encoded), 0x4e4f534a) + encoded +
              struct.pack("<II", len(restored_binary), 0x004e4942) + restored_binary)
    path.write_bytes(result)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--models", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    # Validate every input before writing the actual repository assets.
    import tempfile
    with tempfile.TemporaryDirectory() as folder:
        output = {}
        for path in sorted(args.models.glob("*.glb")):
            temporary = Path(folder) / path.name
            temporary.write_bytes(path.read_bytes())
            output[path.stem] = restore(temporary, args.reference)
        if len(output) != 14:
            raise ValueError("Expected all fourteen campus models")
        for path in sorted(args.models.glob("*.glb")):
            path.write_bytes((Path(folder) / path.name).read_bytes())
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(output, indent=2) + "\n")
    print("CAMPUS COLORS RESTORED:", len(output), "models; original geometry binary unchanged")


if __name__ == "__main__":
    main()
