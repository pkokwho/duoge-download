extends SceneTree
func _initialize() -> void:
    call_deferred("_run")
func _run() -> void:
    var output := "/workspace/duoduo-env/render-check/original-meshes"
    DirAccess.make_dir_recursive_absolute(output)
    var report := {}
    for kind in ["barrier", "bench", "books", "bus", "bus_stop", "cafe", "coin", "gate", "magnet", "parcel", "school", "slide", "store", "tree"]:
        var node = load("res://assets/models/campus/" + kind + ".glb").instantiate()
        var surfaces := []
        for instance in node.find_children("*", "MeshInstance3D", true, false):
            for surface in range(instance.mesh.get_surface_count()):
                var arrays: Array = instance.mesh.surface_get_arrays(surface)
                var prefix: String = output + "/" + kind + "-" + str(surfaces.size())
                var positions: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
                var colors: PackedColorArray = arrays[Mesh.ARRAY_COLOR]
                var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
                for item in [["positions", positions.to_byte_array()], ["colors", colors.to_byte_array()], ["indices", indices.to_byte_array()]]:
                    var file := FileAccess.open(prefix + "." + item[0] + ".bin", FileAccess.WRITE)
                    file.store_buffer(item[1])
                    file.close()
                surfaces.append({"vertices": positions.size(), "colors": colors.size(), "indices": indices.size(), "mesh": str(instance.name)})
        report[kind] = surfaces
        node.free()
    var file := FileAccess.open(output + "/manifest.json", FileAccess.WRITE)
    file.store_string(JSON.stringify(report, "  "))
    file.close()
    print("ORIGINAL MESH EXPORT OK: ", report.size(), " models")
    quit()
