# 程序化建模"舵舵"卡通角色：班主任（黑短寸/浓眉/短胡茬/微胖/电路板T恤/蓝短裤/白鞋）
# 产出：teacher.glb 静态多零件模型（零件名保留，动画由 Godot 程序化驱动）+ preview.png
# 用法：blender --background --python build_teacher.py
import bpy
import math
import os
import random

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
GLB_PATH = os.path.join(OUT_DIR, "..", "..", "assets", "models", "teacher", "teacher.glb")
PREVIEW_PATH = os.path.join(OUT_DIR, "preview.png")

# ── 清空场景 ──
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene

# ── 材质 ──
def mat(name, color, rough=0.75):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Roughness"].default_value = rough
    return m

SKIN = mat("skin", (0.93, 0.70, 0.55))
HAIR = mat("hair", (0.04, 0.04, 0.05))
SHIRT = mat("shirt", (0.075, 0.08, 0.10))
PANTS = mat("pants", (0.16, 0.40, 0.88))
SHOE = mat("shoe", (0.90, 0.90, 0.93), 0.5)
EYEW = mat("eyew", (0.95, 0.95, 0.95), 0.3)
EYEB = mat("eyeb", (0.03, 0.03, 0.03), 0.3)
STUB = mat("stub", (0.16, 0.13, 0.11))

# ── 电路板 T 恤贴图（64x64 像素画：黑底白线橙点） ──
def circuit_texture():
    img = bpy.data.images.new("circuit", 64, 64)
    px = [0.075, 0.08, 0.10, 1.0] * (64 * 64)
    rnd = random.Random(20261021)
    def rect(x, y, w, h, c):
        for yy in range(max(0, y), min(64, y + h)):
            for xx in range(max(0, x), min(64, x + w)):
                i = (yy * 64 + xx) * 4
                px[i:i + 3] = c
    white = (0.75, 0.82, 0.92)
    orange = (0.95, 0.62, 0.15)
    for _ in range(14):
        x, y = rnd.randint(2, 58), rnd.randint(2, 58)
        for _ in range(rnd.randint(2, 5)):
            horiz = rnd.random() < 0.5
            d = rnd.randint(6, 14) * (1 if rnd.random() < 0.5 else -1)
            if horiz:
                rect(min(x, x + d), y, abs(d) + 1, 2, white)
                x = max(0, min(62, x + d))
            else:
                rect(x, min(y, y + d), 2, abs(d) + 1, white)
                y = max(0, min(62, y + d))
        rect(x - 1, y - 1, 3, 3, orange)
    img.pixels.foreach_set(px)
    img.pack()
    return img

circuit_mat = bpy.data.materials.new("circuit")
circuit_mat.use_nodes = True
nt = circuit_mat.node_tree
bsdf = nt.nodes["Principled BSDF"]
bsdf.inputs["Roughness"].default_value = 0.6
tex = nt.nodes.new("ShaderNodeTexImage")
tex.image = circuit_texture()
tex.interpolation = 'Closest'
nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])

# ── 建模工具 ──
parts = []

def add_sphere(name, loc, scale, material, seg=24, ring=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=seg, ring_count=ring, radius=1.0, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    bpy.ops.object.shade_smooth()
    o.data.materials.append(material)
    bpy.ops.object.transform_apply(scale=True)
    parts.append(o)
    return o

def add_capsule(name, loc, r, length, material):
    # Blender 5.x 无 capsule 原语：圆柱 + subsurf 圆润化
    bpy.ops.mesh.primitive_cylinder_add(radius=r, depth=length, location=loc, vertices=24)
    o = bpy.context.active_object
    o.name = name
    bpy.ops.object.shade_smooth()
    sub = o.modifiers.new("Sub", 'SUBSURF')
    sub.levels = sub.render_levels = 2
    o.data.materials.append(material)
    parts.append(o)
    return o

def add_box(name, loc, scale, material, rot=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    bpy.ops.object.transform_apply(scale=True, rotation=True)
    o.data.materials.append(material)
    sub = o.modifiers.new("Sub", 'SUBSURF')
    sub.levels = sub.render_levels = 2
    parts.append(o)
    return o

# ═══ 身体零件（脸朝 -Y，单位米，总高约 1.8） ═══
add_sphere("head", (0, 0, 1.56), (0.30, 0.28, 0.27), SKIN)
add_sphere("nose", (0, -0.27, 1.52), (0.045, 0.05, 0.05), SKIN, seg=16, ring=10)
add_sphere("hair_top", (0, 0.02, 1.71), (0.305, 0.29, 0.175), HAIR)
add_sphere("hair_back", (0, 0.15, 1.56), (0.26, 0.17, 0.21), HAIR)
add_box("brow.L", (-0.125, -0.265, 1.655), (0.16, 0.04, 0.055), HAIR)
add_box("brow.R", (0.125, -0.265, 1.655), (0.16, 0.04, 0.055), HAIR)
add_sphere("eye.L", (-0.125, -0.25, 1.565), (0.055, 0.028, 0.055), EYEW, seg=16, ring=10)
add_sphere("eye.R", (0.125, -0.25, 1.565), (0.055, 0.028, 0.055), EYEW, seg=16, ring=10)
add_sphere("pupil.L", (-0.125, -0.272, 1.565), (0.022, 0.012, 0.024), EYEB, seg=12, ring=8)
add_sphere("pupil.R", (0.125, -0.272, 1.565), (0.022, 0.012, 0.024), EYEB, seg=12, ring=8)
add_sphere("stubble", (0, -0.05, 1.45), (0.21, 0.15, 0.105), STUB)
add_box("mouth", (0, -0.272, 1.475), (0.09, 0.02, 0.02), EYEB)
torso = add_sphere("torso", (0, 0, 1.06), (0.40, 0.26, 0.44), SHIRT)
torso.data.materials.clear()
torso.data.materials.append(circuit_mat)
# 背面白色圆环装饰（跑动中玩家看的是背面，加高辨识度标志）
WHITE = mat("white", (0.94, 0.94, 0.96), 0.5)
bpy.ops.mesh.primitive_torus_add(major_radius=0.16, minor_radius=0.035, location=(0, 0.255, 1.12), rotation=(math.radians(90), 0, 0))
ring = bpy.context.active_object
ring.name = "back_ring"
ring.scale = (1.0, 1.0, 0.8)
bpy.ops.object.shade_smooth()
ring.data.materials.append(WHITE)
bpy.ops.object.transform_apply(scale=True)
parts.append(ring)
add_sphere("hips", (0, 0, 0.74), (0.30, 0.24, 0.27), PANTS)
for s in (-1, 1):
    side = "L" if s < 0 else "R"
    add_capsule(f"arm_lo.{side}", (s * 0.48, 0, 1.08), 0.085, 0.55, SKIN)
    add_sphere(f"sleeve.{side}", (s * 0.42, 0, 1.35), (0.13, 0.12, 0.15), SHIRT, seg=16, ring=10)
    add_sphere(f"hand.{side}", (s * 0.50, 0, 0.76), (0.075, 0.075, 0.09), SKIN, seg=16, ring=10)
    add_capsule(f"leg_up.{side}", (s * 0.17, 0, 0.58), 0.115, 0.40, PANTS)
    add_capsule(f"leg_lo.{side}", (s * 0.17, -0.005, 0.29), 0.09, 0.34, SKIN)
    add_box(f"shoe.{side}", (s * 0.17, -0.05, 0.055), (0.17, 0.30, 0.11), SHOE)

# ═══ 导出 GLB：静态多零件模型（动画由 Godot 程序化驱动） ═══
os.makedirs(os.path.dirname(GLB_PATH), exist_ok=True)
bpy.ops.export_scene.gltf(
    filepath=GLB_PATH,
    export_format='GLB',
    export_apply=True,
    export_yup=True,
)
print("GLB saved:", GLB_PATH)

# ═══ 预览渲染（EEVEE 真实材质光照） ═══
cam_data = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cam_data)
scene.collection.objects.link(cam)
cam.location = (0, -4.2, 1.05)
cam.rotation_euler = (math.radians(86), 0, 0)
cam_data.lens = 42
scene.camera = cam

def add_sun(name, loc, energy, rot):
    ld = bpy.data.lights.new(name, 'SUN')
    ld.energy = energy
    lo = bpy.data.objects.new(name, ld)
    lo.location = loc
    lo.rotation_euler = rot
    scene.collection.objects.link(lo)
    return lo

add_sun("key", (-2, -3, 3), 3.0, (math.radians(45), 0, math.radians(-25)))
add_sun("fill", (3, -2, 1.5), 0.8, (math.radians(70), 0, math.radians(40)))
add_sun("rim", (0, 3, 2.5), 1.5, (math.radians(-135), 0, 0))

scene.render.engine = 'BLENDER_EEVEE'
scene.view_settings.view_transform = 'Standard'
scene.render.resolution_x = 540
scene.render.resolution_y = 720
scene.render.filepath = PREVIEW_PATH
try:
    bpy.ops.render.render(write_still=True)
except Exception as e:
    print("EEVEE failed, fallback Workbench:", e)
    scene.render.engine = 'BLENDER_WORKBENCH'
    scene.display.shading.light = 'STUDIO'
    scene.display.shading.color_type = 'MATERIAL'
    bpy.ops.render.render(write_still=True)
print("Preview saved:", PREVIEW_PATH)
print("BUILD OK")
