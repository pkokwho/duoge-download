# 探针：验证 djb.glb 导入后网格物体的变换（怀疑带旋转/缩放，导致权重分区 carve 错空间）
import bpy
import math
import mathutils

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=r"D:\舵舵快跑\djb.glb")
for o in bpy.context.scene.objects:
    print("OBJ", o.name, o.type,
          "loc=", tuple(round(c, 4) for c in o.location),
          "scale=", tuple(round(c, 4) for c in o.scale),
          "rot_euler=", tuple(round(math.degrees(c), 2) for c in o.rotation_euler))
obj = [o for o in bpy.context.scene.objects if o.type == 'MESH'][0]
mn = mathutils.Vector((1e9,) * 3); mx = mathutils.Vector((-1e9,) * 3)
lmn = mathutils.Vector((1e9,) * 3); lmx = mathutils.Vector((-1e9,) * 3)
for v in obj.data.vertices:
    w = obj.matrix_world @ v.co
    for i in range(3):
        mn[i] = min(mn[i], w[i]); mx[i] = max(mx[i], w[i])
        lmn[i] = min(lmn[i], v.co[i]); lmx[i] = max(lmx[i], v.co[i])
print("WORLD bbox  mn=", tuple(round(c, 3) for c in mn), " mx=", tuple(round(c, 3) for c in mx))
print("LOCAL bbox  mn=", tuple(round(c, 3) for c in lmn), " mx=", tuple(round(c, 3) for c in lmx))
