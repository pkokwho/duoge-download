extends SceneTree
## Headless integration check for imported clips and gameplay transitions.
## godot --headless --path . --script res://tools/blender_build/verify_runner.gd

var stage: Node3D
var player

func _initialize() -> void:
	call_deferred("_run")

func _expect(condition: bool, message: String) -> bool:
	if not condition:
		push_error("RUNNER FAIL: " + message)
		quit(1)
	return condition

func _run() -> void:
	stage = load("res://scenes/model_test.tscn").instantiate()
	root.add_child(stage)
	player = stage.player
	await create_timer(1.0).timeout
	if not _expect(player._current_clip == "Run" and player.is_on_floor(), "grounded Run"):
		return
	var animation_player: AnimationPlayer = player._animation_player
	if not _expect(animation_player != null and player._animation_names.size() == 4, "four imported clips"):
		return
	# Confirm that the imported animation changes the actual new knee joint.
	player.set_process(false)
	animation_player.pause()
	animation_player.play(player._animation_names["Run"])
	animation_player.seek(0.0, true)
	var knee: int = player._skel.find_bone("shin.L")
	var first: Quaternion = player._skel.get_bone_pose_rotation(knee)
	animation_player.seek(0.40, true)
	var second: Quaternion = player._skel.get_bone_pose_rotation(knee)
	if not _expect(first.angle_to(second) > 0.2, "imported knee animation"):
		return
	# The airborne clip must change shape over time, not hold one crouched pose.
	animation_player.play(player._animation_names["Jump"])
	animation_player.seek(0.0, true)
	var jump_start: Quaternion = player._skel.get_bone_pose_rotation(knee)
	animation_player.seek(0.35, true)
	var jump_apex: Quaternion = player._skel.get_bone_pose_rotation(knee)
	if not _expect(jump_start.angle_to(jump_apex) > 0.2, "Jump takeoff and apex differ"):
		return
	var head_bone: int = player._skel.find_bone("head")
	for side in ["L", "R"]:
		var hand_bone: int = player._skel.find_bone("hand." + side)
		if not _expect(player._skel.get_bone_global_pose(hand_bone).origin.y >
				player._skel.get_bone_global_pose(head_bone).origin.y + 0.05,
				"Jump " + side + " hand above head at apex"):
			return
	player.set_process(true)
	player.jump()
	await create_timer(0.10).timeout
	if not _expect(player._current_clip == "Jump", "Jump transition"):
		return
	await create_timer(1.0).timeout
	if not _expect(player._current_clip == "Run" and player.is_on_floor(), "landing returns to Run"):
		return
	player.start_slide()
	await create_timer(0.1).timeout
	if not _expect(player._current_clip == "Slide", "Slide transition"):
		return
	await create_timer(0.85).timeout
	if not _expect(player._current_clip == "Run", "slide ends in Run"):
		return
	player.set_physics_process(false)
	await create_timer(0.1).timeout
	if not _expect(player._current_clip == "Idle", "menu Idle"):
		return
	player.die()
	await create_timer(0.85).timeout
	player.reset_run()
	if not _expect(player._current_clip == "Idle" and player.alive, "restart restores Idle"):
		return
	print("RUNNER OK: four baked clips, knee motion, Jump hands overhead, Run/Jump/Slide/Idle/restart")
	stage.queue_free()
	await process_frame
	quit(0)
