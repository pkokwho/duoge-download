# 预览混元模型：前后左右四个角度，确认脸朝向与模型质量
import bpy
import math
import os

SRC = r"D:\舵舵快跑\djb.glb"
OUT_DIR = r"D:\舵舵快跑\tools\blender_build"
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=SRC)
scene = bpy.context.scene

# 灯光
def add_sun(name, loc, energy, rot):
    ld = bpy.data.lights.new(name, 'SUN')
    ld.energy = energy
    lo = bpy.data.objects.new(name, ld)
    lo.location = loc
    lo.rotation_euler = rot
    scene.collection.objects.link(lo)
add_sun("key", (-2, -3, 3), 3.0, (math.radians(45), 0, math.radians(-25)))
add_sun("fill", (3, -2, 1.5), 0.8, (math.radians(70), 0, math.radians(40)))

cam_data = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cam_data)
scene.collection.objects.link(cam)
scene.camera = cam
cam_data.lens = 45

scene.render.engine = 'BLENDER_EEVEE'
scene.view_settings.view_transform = 'Standard'
scene.render.resolution_x = 320
scene.render.resolution_y = 480

views = {
    "front": (0, -2.6, 0.75, 90),     # 从 -Y 看
    "back":  (0, 2.6, 0.75, 90),      # 从 +Y 看
    "left":  (-2.0, 0, 0.75, 90),     # 从 -X 看（朝向 +X）
}
for name, (x, y, z, elev) in views.items():
    cam.location = (x, y, z)
    cam.rotation_euler = (math.radians(elev), 0, 0)
    dir_to = mathutils_logic = (0, 0, 0.6)
    # 手动 look_at
    d = __import__('mathutils').Vector((0, 0, 0.6)) - cam.location
    cam.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
    scene.render.filepath = os.path.join(OUT_DIR, f"djb_{name}.png")
    bpy.ops.render.render(write_still=True)
print("PREVIEW DONE")