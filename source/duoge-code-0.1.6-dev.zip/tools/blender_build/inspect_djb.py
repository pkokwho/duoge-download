# 探测混元生成的 djb.glb：网格/面数/包围盒/骨架/纹理
import bpy
import sys

SRC = r"D:\舵舵快跑\djb.glb"
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=SRC)

print("=== OBJECTS ===")
total_tris = 0
for o in bpy.context.scene.objects:
    if o.type == 'MESH':
        tris = sum(len(p.vertices) - 2 for p in o.data.polygons)
        total_tris += tris
        print(f"MESH {o.name} verts={len(o.data.vertices)} polys={len(o.data.polygons)}~tris={tris} matslots={len(o.data.materials)}")
    elif o.type == 'ARMATURE':
        print(f"ARMATURE {o.name} bones={len(o.data.bones)}")
    else:
        print(f"{o.type} {o.name}")

# 包围盒（合并所有网格）
import mathutils
bb_min = mathutils.Vector((1e9, 1e9, 1e9))
bb_max = mathutils.Vector((-1e9, -1e9, -1e9))
for o in bpy.context.scene.objects:
    if o.type == 'MESH':
        for v in o.bound_box:
            w = o.matrix_world @ mathutils.Vector(v)
            bb_min.x = min(bb_min.x, w.x); bb_min.y = min(bb_min.y, w.y); bb_min.z = min(bb_min.z, w.z)
            bb_max.x = max(bb_max.x, w.x); bb_max.y = max(bb_max.y, w.y); bb_max.z = max(bb_max.z, w.z)
print(f"TOTAL tris={total_tris}")
print(f"BBOX min={bb_min} max={bb_max} size={bb_max - bb_min}")

print("=== TEXTURES ===")
for img in bpy.data.images:
    print(f"IMG {img.name} {img.size[0]}x{img.size[1]}")
print("=== ARMATURES ===")
for a in bpy.data.armatures:
    print(f"ARMATURE {a.name} bones={len(a.bones)}")
print("INSPECT DONE")