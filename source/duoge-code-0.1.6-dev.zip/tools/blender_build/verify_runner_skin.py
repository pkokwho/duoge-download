"""Check rebuilt skin coverage, ground penetration and loop seam in Blender."""
from pathlib import Path
import bpy
import numpy as np

base = Path(__file__).resolve().parents[2]
bpy.ops.wm.open_mainfile(filepath=str(base / "tools/runner-authoring/teacher-runner.blend"))
rig = bpy.data.objects["RunnerRig"]
mesh = next(o for o in bpy.data.objects if o.type == "MESH")
assert all(abs(sum(g.weight for g in v.groups)-1) < .001 for v in mesh.data.vertices), "Unbound mesh"
rig.animation_data.action = bpy.data.actions["Run"]
for track in rig.animation_data.nla_tracks:
    track.mute = True
first = None
minimum = 1.0
for frame in range(1, 22):
    bpy.context.scene.frame_set(frame)
    bpy.context.view_layer.update()
    evaluated = mesh.evaluated_get(bpy.context.evaluated_depsgraph_get())
    data = evaluated.to_mesh()
    positions = np.empty(len(data.vertices)*3, dtype=np.float32)
    data.vertices.foreach_get("co", positions)
    positions = positions.reshape(-1, 3)
    minimum = min(minimum, float(positions[:, 2].min()))
    if frame == 1:
        first = positions.copy()
    if frame == 21:
        seam = float(np.linalg.norm(positions-first, axis=1).max())
    evaluated.to_mesh_clear()
assert minimum > -.01, f"Shoe penetrates floor: {minimum:.4f}m"
assert seam < .0001, f"Run loop pops: {seam:.6f}m"
print(f"SKIN OK: all vertices weighted, floor min={minimum:.4f}m, loop seam={seam:.6f}m")
