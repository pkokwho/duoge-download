"""Rebuild teacher skin and baked clips from an unrigged mesh. Blender 4.3+.
Run: blender -b --python tools/blender_build/rebuild_runner.py
No weights, bones or actions are taken from the previous character rigs.
"""
from pathlib import Path
import math
import bpy
from mathutils import Vector, Matrix, Quaternion, Euler

BASE = Path(__file__).resolve().parents[2]
ASSETS = BASE / "assets/models/teacher"
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(ASSETS / "teacher_mesh.glb"))
mesh = next(o for o in bpy.data.objects if o.type == "MESH")
world = mesh.matrix_world.copy()
mesh.parent = None
mesh.matrix_world = world
mesh.animation_data_clear()
mesh.vertex_groups.clear()
for modifier in list(mesh.modifiers):
    mesh.modifiers.remove(modifier)
for obj in list(bpy.data.objects):
    if obj != mesh:
        bpy.data.objects.remove(obj, do_unlink=True)
bpy.context.view_layer.objects.active = mesh
mesh.select_set(True)
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# The textured source is triangle soup. Heat weights need a continuous surface.
proxy = mesh.copy()
proxy.data = mesh.data.copy()
bpy.context.collection.objects.link(proxy)
proxy.name = "SkinProxy"
bpy.context.view_layer.objects.active = proxy
remesh = proxy.modifiers.new("ContinuousSkin", "REMESH")
remesh.mode = "VOXEL"
remesh.voxel_size = 0.022
bpy.ops.object.modifier_apply(modifier=remesh.name)

armature = bpy.data.armatures.new("RunnerSkeleton")
rig = bpy.data.objects.new("RunnerRig", armature)
bpy.context.collection.objects.link(rig)
bpy.context.view_layer.objects.active = rig
bpy.ops.object.mode_set(mode="EDIT")
def bone(name, head, tail, parent=None):
    item = armature.edit_bones.new(name)
    item.head, item.tail = head, tail
    if parent:
        item.parent = armature.edit_bones[parent]
bone("hips", (0, 0, .88), (0, 0, 1.02))
bone("spine", (0, 0, 1.02), (0, 0, 1.23), "hips")
bone("chest", (0, 0, 1.23), (0, 0, 1.43), "spine")
bone("neck", (0, 0, 1.43), (0, 0, 1.58), "chest")
bone("head", (0, 0, 1.58), (0, 0, 1.77), "neck")
for side, sign in (("L", -1), ("R", 1)):
    bone("upper_arm." + side, (sign*.24, .02, 1.43), (sign*.335, 0, 1.20), "chest")
    bone("forearm." + side, (sign*.335, 0, 1.20), (sign*.4, -.06, 1.00), "upper_arm." + side)
    bone("hand." + side, (sign*.4, -.06, 1.00), (sign*.42, -.10, .85), "forearm." + side)
    bone("thigh." + side, (sign*.11, .02, .91), (sign*.15, .04, .52), "hips")
    bone("shin." + side, (sign*.15, .04, .52), (sign*.18, .05, .15), "thigh." + side)
    bone("foot." + side, (sign*.18, .05, .15), (sign*.20, -.08, .06), "shin." + side)
bpy.ops.object.mode_set(mode="OBJECT")
bpy.ops.object.select_all(action="DESELECT")
proxy.select_set(True)
rig.select_set(True)
bpy.context.view_layer.objects.active = rig
bpy.ops.object.parent_set(type="ARMATURE_AUTO")

bpy.ops.object.select_all(action="DESELECT")
mesh.select_set(True)
bpy.context.view_layer.objects.active = mesh
transfer = mesh.modifiers.new("TransferSkin", "DATA_TRANSFER")
transfer.object = proxy
transfer.use_vert_data = True
transfer.data_types_verts = {"VGROUP_WEIGHTS"}
transfer.vert_mapping = "POLYINTERP_NEAREST"
transfer.layers_vgroup_select_src = "ALL"
transfer.layers_vgroup_select_dst = "NAME"
bpy.ops.object.datalayout_transfer(modifier=transfer.name)
bpy.ops.object.modifier_apply(modifier=transfer.name)
bpy.ops.object.vertex_group_limit_total(limit=4)
bpy.ops.object.vertex_group_normalize_all(lock_active=False)
assert all(abs(sum(g.weight for g in v.groups)-1) < .001 for v in mesh.data.vertices), "Unbound vertex"
counts = {group.name: 0 for group in mesh.vertex_groups}
for v in mesh.data.vertices:
    for g in v.groups:
        if g.weight > .2:
            counts[mesh.vertex_groups[g.group].name] += 1
assert all(counts[n] > 100 for n in counts), counts
print("FRESH SKIN", counts)
mesh.parent = rig
skin = mesh.modifiers.new("RunnerSkin", "ARMATURE")
skin.object = rig
bpy.data.objects.remove(proxy, do_unlink=True)

REST = {b.name: b.matrix_local.copy() for b in armature.bones}
HEADS = {b.name: b.head_local.copy() for b in armature.bones}
TAILS = {b.name: b.tail_local.copy() for b in armature.bones}
X = Vector((1, 0, 0))
def orient(name, start, end):
    rest = REST[name]
    direction = TAILS[name] - HEADS[name]
    rotation = direction.rotation_difference(end-start)
    rig.pose.bones[name].matrix = Matrix.Translation(start) @ rotation.to_matrix().to_4x4() @ rest.to_3x3().to_4x4()
    bpy.context.view_layer.update()

def local_rotation(name, angle):
    basis = REST[name].to_quaternion()
    rig.pose.bones[name].rotation_quaternion = basis.inverted() @ Quaternion(X, angle) @ basis

def local_euler(name, pitch=0, roll=0, yaw=0):
    basis = REST[name].to_quaternion()
    rig.pose.bones[name].rotation_quaternion = basis.inverted() @ Euler((pitch, roll, yaw)).to_quaternion() @ basis

def ik_leg(side, ankle, foot_pitch=0):
    thigh, shin, foot = ("thigh."+side, "shin."+side, "foot."+side)
    pelvis_delta = rig.pose.bones["hips"].matrix @ REST["hips"].inverted()
    hip = pelvis_delta @ HEADS[thigh]
    l1 = (TAILS[thigh]-HEADS[thigh]).length
    l2 = (TAILS[shin]-HEADS[shin]).length
    direction = ankle-hip
    distance = min(direction.length, l1+l2-.002)
    unit = direction.normalized()
    # Knees bend toward the face (-Y), never backward.
    pole = Vector((0, -1, 0))
    bend = (pole-unit*unit.dot(pole)).normalized()
    along = (l1*l1-l2*l2+distance*distance)/(2*distance)
    height = math.sqrt(max(0, l1*l1-along*along))
    knee = hip + unit*along + bend*height
    ankle = hip + unit*distance
    orient(thigh, hip, knee)
    orient(shin, knee, ankle)
    toe = ankle + Quaternion(X, foot_pitch) @ (TAILS[foot]-HEADS[foot])
    orient(foot, ankle, toe)

def arm_pose(side, shoulder_angle, elbow_angle, wrist_inset=0):
    upper, forearm, hand = ("upper_arm."+side, "forearm."+side, "hand."+side)
    sign = -1 if side == "L" else 1
    chest_delta = rig.pose.bones["chest"].matrix @ REST["chest"].inverted()
    shoulder = chest_delta @ HEADS[upper]
    torso = chest_delta.to_quaternion()
    upper_rotation = torso @ Quaternion(X, shoulder_angle)
    elbow = shoulder + upper_rotation @ (TAILS[upper]-HEADS[upper])
    lower_rotation = upper_rotation @ Quaternion(X, elbow_angle)
    forearm_delta = lower_rotation @ (TAILS[forearm]-HEADS[forearm])
    if wrist_inset:
        # Tuck the fist inward without changing forearm length or the elbow pivot.
        length = forearm_delta.length
        forearm_delta.x -= sign * wrist_inset
        forearm_delta.length = length
    wrist = elbow + forearm_delta
    palm = wrist + lower_rotation @ (TAILS[hand]-HEADS[hand])
    orient(upper, shoulder, elbow)
    orient(forearm, elbow, wrist)
    orient(hand, wrist, palm)

def reset():
    for p in rig.pose.bones:
        p.matrix_basis = Matrix.Identity(4)
        p.rotation_mode = "QUATERNION"

def pelvis(z, lean, twist=0, roll=0, sway=0):
    root = rig.pose.bones["hips"]
    root.matrix = Matrix.Translation(HEADS["hips"]+Vector((sway, 0, z))) @ Euler((lean, roll, twist)).to_matrix().to_4x4() @ REST["hips"].to_3x3().to_4x4()
    bpy.context.view_layer.update()

def smooth(a, b, t):
    t = max(0, min(1, t))
    return a+(b-a)*t*t*(3-2*t)

def keyed(t, points):
    for (start, a), (end, b) in zip(points, points[1:]):
        if t <= end:
            return smooth(a, b, (t-start)/(end-start))
    return points[-1][1]

def foot_path(t, sign):
    # Linear ground travel, then heel recovery and forward swing.
    if t < .44:
        y = -.28 + .70*t/.44
        z = .15
        pitch = smooth(0, .55, (t-.28)/.16)
    elif t < .68:
        u = (t-.44)/.24
        y = smooth(.42, .10, u)
        z = smooth(.15, .63, u)
        pitch = smooth(.55, .08, u)
    else:
        u = (t-.68)/.32
        y = smooth(.10, -.28, u)
        z = smooth(.63, .15, u)
        pitch = smooth(.08, 0, u)
    # Lift the ankle as the heel rolls up; otherwise a toe-down foot rotates
    # through the floor during the last part of the support phase.
    z += .007 + .18 * math.sin(max(0, pitch))
    return Vector((sign*.18, y, z)), pitch

def pose(clip, t):
    reset()
    if clip == "Run":
        stride = math.sin(2*math.pi*t)
        bounce = math.cos(4*math.pi*t)
        pelvis(-.075+.035*(1-bounce), .17+.025*bounce,
               .075*stride, .06*stride, .025*stride)
        # The loaded side drops and rotates with each stride; the chest and
        # head partly counter-rotate so the face still points down the track.
        local_euler("spine", .11+.01*bounce, -.02*stride, -.015*stride)
        local_euler("chest", .06, -.015*stride, -.015*stride)
        local_euler("head", -.23, -.015*stride, -.02*stride)
        bpy.context.view_layer.update()
        for side, sign, offset in (("L", -1, 0), ("R", 1, .5)):
            phase = (t+offset)%1
            ankle, pitch = foot_path(phase, sign)
            ik_leg(side, ankle, pitch)
            swing = math.cos(2*math.pi*phase)
            # Positive X drives the elbow behind the body. The rear stroke is
            # longer than the forward stroke, with a bent elbow and tucked fist.
            arm_pose(side, .15+.98*swing, -1.42+.12*swing, .08)
    elif clip == "Idle":
        pelvis(.004*math.sin(2*math.pi*t), 0)
        for side in ("L", "R"):
            arm_pose(side, 0, -.08)
    elif clip == "Jump":
        # Distinct takeoff, airborne tuck and landing preparation. The Player
        # owns vertical travel; these targets are only the pose inside it.
        pelvis(keyed(t, [(0, -.09), (.18, .025), (.50, -.025), (1, -.10)]),
               keyed(t, [(0, .20), (.35, .12), (.68, .08), (1, .20)]))
        local_rotation("spine", keyed(t, [(0, .07), (.4, .02), (1, .08)]))
        local_rotation("head", keyed(t, [(0, -.12), (.5, -.07), (1, -.12)]))
        bpy.context.view_layer.update()
        foot_y = keyed(t, [(0, -.08), (.18, -.12), (.50, -.25), (.80, -.20), (1, -.10)])
        foot_z = keyed(t, [(0, .15), (.18, .15), (.50, .49), (.80, .16), (1, .16)])
        # Drive both arms upward with the takeoff. Hold a soft elbow bend near
        # the apex, then lower the hands before the feet meet the ground.
        shoulder = keyed(t, [(0, .35), (.18, -1.10), (.35, -2.30),
                             (.68, -2.25), (.86, -1.0), (1, .10)])
        elbow = keyed(t, [(0, -1.20), (.20, -.65), (.35, -.18),
                          (.68, -.20), (.85, -.65), (1, -1.05)])
        for side, sign in (("L",-1),("R",1)):
            lead = math.sin(math.pi*t)
            ik_leg(side, Vector((sign*.18, foot_y+sign*.10*lead,
                                 foot_z-sign*.06*lead)), .08)
            arm_pose(side, shoulder, elbow, .03)
    elif clip == "Slide":
        pelvis(-.52, -.85)
        for side, sign in (("L",-1),("R",1)):
            ik_leg(side, Vector((sign*.18, -.48 if sign<0 else -.30, .155)), 0)
            arm_pose(side, -.15, -.7)

scene = bpy.context.scene
scene.render.fps = 30
rig.animation_data_create()
actions = []
for clip, frames in (("Idle", 60), ("Run", 20), ("Jump", 20), ("Slide", 20)):
    action = bpy.data.actions.new(clip)
    rig.animation_data.action = action
    for frame in range(frames+1):
        scene.frame_set(frame+1)
        pose(clip, frame/frames)
        for p in rig.pose.bones:
            p.keyframe_insert("location", frame=frame+1, group=p.name)
            p.keyframe_insert("rotation_quaternion", frame=frame+1, group=p.name)
            p.keyframe_insert("scale", frame=frame+1, group=p.name)
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.interpolation = "LINEAR"
    actions.append(action)
rig.animation_data.action = None
for action in actions:
    track = rig.animation_data.nla_tracks.new()
    track.name = action.name
    track.strips.new(action.name, 1, action)
    track.mute = True
reset()
scene.frame_set(1)
scene.frame_end = 61
bpy.ops.object.select_all(action="DESELECT")
mesh.select_set(True)
rig.select_set(True)
bpy.context.view_layer.objects.active = rig
# Keep Blender authoring files out of Godot's resource scanner.
authoring = BASE / "tools/runner-authoring"
authoring.mkdir(exist_ok=True)
(authoring/".gdignore").touch()
bpy.ops.wm.save_as_mainfile(filepath=str(authoring/"teacher-runner.blend"))
bpy.ops.export_scene.gltf(filepath=str(ASSETS/"teacher_runner.glb"), export_format="GLB",
                          use_selection=True, export_animations=True, export_animation_mode="ACTIONS",
                          export_force_sampling=True, export_nla_strips=True)
print("RUNNER BUILT", ASSETS/"teacher_runner.glb")
