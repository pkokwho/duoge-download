@tool
extends EditorPlugin
var export_plugin: EditorExportPlugin
func _enter_tree() -> void :
	export_plugin = AndroidUpdaterExport.new()
	add_export_plugin(export_plugin)
func _exit_tree() -> void :
	remove_export_plugin(export_plugin)
	export_plugin = null
class AndroidUpdaterExport extends EditorExportPlugin:
	func _supports_platform(platform: EditorExportPlatform) -> bool:
		return platform is EditorExportPlatformAndroid
	func _get_name() -> String:
		return "DuogeUpdater"
	func _get_android_libraries(_platform: EditorExportPlatform, _debug: bool) -> PackedStringArray:
		return PackedStringArray(["duoge_updater/duoge-updater.aar"])
