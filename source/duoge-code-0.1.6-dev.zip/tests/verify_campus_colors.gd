extends SceneTree

func _initialize() -> void:
	create_timer(30).timeout.connect(func():
		push_error("CAMPUS COLORS FAIL: verification did not finish")
		quit(1))
	call_deferred("_run")

func _expect(condition: bool, message: String) -> bool:
	if not condition:
		push_error("CAMPUS COLORS FAIL: " + message)
		quit(1)
	return condition

func _run() -> void:
	var reference := "res://tests/fixtures/campus_color_reference.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--reference="):
			reference = argument.trim_prefix("--reference=")
	var expected: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(reference))
	if not _expect(expected.size() == 14, "Missing original campus color references"):
		return
	var total := 0
	for kind in expected:
		var root_node = load("res://assets/models/campus/" + kind + ".glb").instantiate()
		var surfaces := 0
		for instance in root_node.find_children("*", "MeshInstance3D", true, false):
			for surface in range(instance.mesh.get_surface_count()):
				var arrays: Array = instance.mesh.surface_get_arrays(surface)
				var positions: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
				var colors: PackedColorArray = arrays[Mesh.ARRAY_COLOR] if arrays[Mesh.ARRAY_COLOR] != null else PackedColorArray()
				if not _expect(positions.size() == expected[kind].vertices and colors.size() == positions.size(), kind + " vertex count or colors changed"):
					root_node.free()
					return
				# Import may reorder vertices; compare color attached to each oriented
				# triangle, preserving exact positions, colors and winding instead.
				var vertices: Array[String] = []
				for i in range(positions.size()):
					var p := positions[i]
					var c := colors[i]
					vertices.append(PackedFloat32Array([p.x, p.y, p.z, c.r, c.g, c.b, c.a]).to_byte_array().hex_encode())
				var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
				if indices.is_empty():
					for i in range(vertices.size()):
						indices.append(i)
				var faces: Array[String] = []
				for i in range(0, indices.size(), 3):
					var a := vertices[indices[i]]
					var b := vertices[indices[i + 1]]
					var c := vertices[indices[i + 2]]
					var canonical := a + b + c
					if b + c + a < canonical:
						canonical = b + c + a
					if c + a + b < canonical:
						canonical = c + a + b
					faces.append(canonical)
				faces.sort()
				if not _expect("".join(faces).sha256_text() == expected[kind].colored_triangles_sha256, kind + " geometry/color associations differ from original APK"):
					root_node.free()
					return
				total += colors.size()
				surfaces += 1
		if not _expect(surfaces == 1, kind + " mesh structure changed"):
			root_node.free()
			return
		root_node.free()
	print("CAMPUS COLORS OK: 14 models, ", total, " vertices; exact original colors and positions")
	quit()
