extends SceneTree

const Service = preload("res://scripts/app_updates.gd")

class NativeStub:
	extends RefCounted
	func getAndroidSdk() -> int:
		return 35

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var service = Service.new()
	root.add_child(service)
	service._native = NativeStub.new()
	service._download_path = "user://announcement-test.apk"
	var panel = preload("res://scripts/update_panel.gd").new()
	root.add_child(panel)
	panel.setup(service, Theme.new())
	assert(panel._details.text.contains("恢复校园"), "Bundled color-fix notes must be available offline")
	var manifest := {
		"schema_version": 1, "version_code": 5, "version_name": "0.1.4-dev",
		"package_name": Service.target_package_name(), "min_android_sdk": 24,
		"apk_url": "https://pkokwho.github.io/duoge-download/downloads/duoge-parkour-0.1.4-dev-arm64.apk",
		"size_bytes": 51248394,
		"sha256": "9c7375b4ee5eaac4507eeb2612be31785481a1dcc9c4af40d05ce5bbceae0c2a",
		"notes": "校园挑战与更新公告"
	}
	# Future releases still offer installation and display their own announcement.
	manifest.version_code = Service.VERSION_CODE + 1
	manifest.version_name = "future-test"
	service.state = Service.State.CHECKING
	service._manifest_complete(HTTPRequest.RESULT_SUCCESS, 200, PackedStringArray(), JSON.stringify(manifest).to_utf8_buffer())
	assert(service.state == Service.State.AVAILABLE)
	assert(panel._details.text.contains(manifest.notes))
	assert(panel._details.text.contains("更新公告"))
	assert(panel._primary.text == "下载并更新")
	# A current-version check retains the notice without offering reinstallation.
	manifest.version_code = Service.VERSION_CODE
	manifest.version_name = Service.VERSION_NAME
	service.state = Service.State.CHECKING
	service._manifest_complete(HTTPRequest.RESULT_SUCCESS, 200, PackedStringArray(), JSON.stringify(manifest).to_utf8_buffer())
	assert(service.state == Service.State.CURRENT)
	assert(service.release.is_empty())
	assert(panel._details.text.contains(manifest.notes))
	assert(panel._primary.text == "检查更新")
	# An older manifest cannot display stale release notes or offer a downgrade.
	manifest.version_code = Service.VERSION_CODE - 1
	service.state = Service.State.CHECKING
	service._manifest_complete(HTTPRequest.RESULT_SUCCESS, 200, PackedStringArray(), JSON.stringify(manifest).to_utf8_buffer())
	assert(service.announcement.is_empty())
	assert(not panel._details.text.contains(manifest.notes))
	assert(panel._primary.text == "检查更新")
	# Existing package, hash, and URL checks still reject invalid announcements.
	manifest.package_name = "other.app"
	assert(Service.validate_manifest(manifest, Service.VERSION_CODE, 35).has("error"))
	manifest.package_name = Service.target_package_name()
	manifest.apk_url = "https://example.com/untrusted.apk"
	assert(Service.validate_manifest(manifest, Service.VERSION_CODE, 35).has("error"))
	manifest.apk_url = "https://pkokwho.github.io/duoge-download/downloads/test.apk"
	manifest.sha256 = "invalid"
	assert(Service.validate_manifest(manifest, Service.VERSION_CODE, 35).has("error"))
	panel.queue_free()
	service.queue_free()
	await process_frame
	print("UPDATE ANNOUNCEMENTS OK: future/current/older versions, UI actions and validation")
	quit()
