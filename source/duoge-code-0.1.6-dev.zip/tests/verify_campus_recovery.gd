extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var campus_script = load("res://scripts/campus_track.gd")
	var coins := 0
	var magnets := 0
	for index in range(63):
		var row: Dictionary = campus_script.pattern(index)
		assert(row.routes.size() <= 1, "More than one coin route in a row")
		for route in row.routes:
			coins += int(route[1])
		if row.magnet:
			magnets += 1
	assert(coins == 219, "Published 0.1.4 coin layout changed")
	assert(magnets == 2, "Published magnet count changed")
	assert(campus_script.SAMPLE_SECONDS == 75.0)
	var game = load("res://scenes/campus.tscn").instantiate()
	root.add_child(game)
	assert(not game.preview, "Formal game incorrectly opens as a preview")
	while game.loading_screen.visible:
		await process_frame
	game._show_start()
	assert(game.track.get_script() == campus_script)
	assert(game.player.visible and game.track.visible)
	assert(not game.player.is_physics_processing() and not game.track.is_physics_processing())
	game._start_game()
	# Simulate the challenge clock with collisions disabled for a controlled survival run.
	game.set_process(false)
	game.player.set_physics_process(false)
	game.player.get_node("Hurtbox").monitoring = false
	game.track.set_physics_process(false)
	for step in range(750):
		game.track._physics_process(0.1)
		if step % 10 == 0:
			await process_frame
	assert(game.track.completed and game.sample_complete)
	assert(is_equal_approx(game.track.elapsed(), 75.0))
	assert(not root.get_node("GameState").playing)
	assert(game.goals[0], "Survival goal missing")
	await create_timer(0.6).timeout
	assert(game.over_screen.visible)
	game._show_start()
	game._start_game()
	assert(not game.track.completed and not game.sample_complete)
	assert(is_zero_approx(game.track.elapsed()))
	game.queue_free()
	await process_frame
	print("CAMPUS RECOVERY OK: 219 coins, two magnets, one route, 75-second finish and replay")
	quit()
