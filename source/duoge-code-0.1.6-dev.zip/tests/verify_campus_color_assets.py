"""Verify restored colors against original-APK references and unchanged geometry bytes."""
import hashlib
import json
from pathlib import Path
import struct

root = Path(__file__).resolve().parents[1]
expected = json.loads((root / "tests/fixtures/campus_color_reference.json").read_text())
models = root / "assets/models/campus"
assert set(expected) == {p.stem for p in models.glob("*.glb")}
total = 0
for kind, reference in expected.items():
    raw = (models / (kind + ".glb")).read_bytes()
    magic, version, size = struct.unpack_from("<III", raw)
    assert (magic, version, size) == (0x46546c67, 2, len(raw))
    length, tag = struct.unpack_from("<II", raw, 12)
    assert tag == 0x4e4f534a
    document = json.loads(raw[20:20 + length])
    offset = 20 + length
    length, tag = struct.unpack_from("<II", raw, offset)
    assert tag == 0x004e4942
    binary = raw[offset + 8:offset + 8 + length]
    assert hashlib.sha256(binary[:reference["original_binary_length"]]).hexdigest() == reference["original_binary_sha256"], kind + " original geometry buffer changed"
    primitives = [p for m in document["meshes"] for p in m["primitives"]]
    assert len(primitives) == 1
    attributes = primitives[0]["attributes"]
    for attribute, width, field in [("POSITION", 12, "positions_sha256"), ("COLOR_0", 16, "colors_sha256")]:
        assert attribute in attributes, kind + " missing " + attribute
        accessor = document["accessors"][attributes[attribute]]
        view = document["bufferViews"][accessor["bufferView"]]
        assert accessor["componentType"] == 5126 and accessor["count"] == reference["vertices"]
        start = view.get("byteOffset", 0) + accessor.get("byteOffset", 0)
        stride = view.get("byteStride", width)
        data = b"".join(binary[start + i * stride:start + i * stride + width] for i in range(accessor["count"]))
        assert hashlib.sha256(data).hexdigest() == reference[field], kind + " differs from original " + attribute
    assert "meshes/force_disable_compression=true" in (models / (kind + ".glb.import")).read_text()
    total += reference["vertices"]
print(f"CAMPUS ASSETS OK: {len(expected)} models, {total} original vertex colors; pre-existing binary data unchanged")
