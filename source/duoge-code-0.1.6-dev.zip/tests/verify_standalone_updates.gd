extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var service = load("res://scripts/app_updates.gd")
	var key := "application/config/android_package"
	var previous = ProjectSettings.get_setting(key, null)
	ProjectSettings.set_setting(key, service.STANDALONE_PACKAGE_NAME)
	assert(service.target_package_name() == "org.duoge.parkour.standalone")
	assert(service.target_manifest_url().ends_with("/update-standalone.json"))
	assert(service.local_release_notes().contains("旧版纪录保留在旧游戏中"))
	var manifest := {
		"schema_version": 1, "version_code": service.VERSION_CODE + 1, "version_name": "future-test",
		"package_name": "org.duoge.parkour.standalone", "min_android_sdk": 29,
		"apk_url": "https://pkokwho.github.io/duoge-download/downloads/standalone-test.apk",
		"size_bytes": 100, "sha256": "a".repeat(64), "notes": "Independent update"
	}
	var valid: Dictionary = service.validate_manifest(manifest, service.VERSION_CODE, 35)
	assert(valid.get("package_name") == "org.duoge.parkour.standalone")
	manifest.package_name = "org.duoge.parkour"
	assert(service.validate_manifest(manifest, service.VERSION_CODE, 35).has("error"))
	ProjectSettings.set_setting(key, service.PACKAGE_NAME)
	assert(service.target_manifest_url().ends_with("/update.json"))
	assert(not service.local_release_notes().contains("旧版纪录保留在旧游戏中"))
	assert(not service.validate_manifest(manifest, service.VERSION_CODE, 35).has("error"))
	manifest.package_name = "org.duoge.parkour.standalone"
	assert(service.validate_manifest(manifest, service.VERSION_CODE, 35).has("error"))
	ProjectSettings.set_setting(key, previous)
	print("STANDALONE UPDATES OK: separate package/channel, cross-package rejection and clear save notice")
	quit()
