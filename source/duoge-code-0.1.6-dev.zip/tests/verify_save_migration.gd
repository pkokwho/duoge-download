extends SceneTree
## Run with isolated XDG_DATA_HOME; verifies old character saves keep their high score.

func _initialize() -> void:
	var save_path := "user://highscore.cfg"
	var old := ConfigFile.new()
	old.set_value("run", "high_score", 12480)
	old.set_value("chars", "duoduo", true)
	old.set_value("chars", "duoge", false)
	old.set_value("chars", "selected", "duoduo")
	old.set_value("future", "test", "kept")
	assert(old.save(save_path) == OK)
	var state = load("res://scripts/game_state.gd").new()
	state.load_high_score()
	assert(state.high_score == 12480, "Old high score was lost")
	state.high_score = 13000
	state.save_high_score()
	var migrated := ConfigFile.new()
	assert(migrated.load(save_path) == OK)
	assert(int(migrated.get_value("run", "high_score")) == 13000)
	assert(not migrated.has_section("chars"), "Old character selection was retained")
	assert(migrated.get_value("future", "test") == "kept")
	print("SAVE MIGRATION OK")
	state.free()
	quit()
