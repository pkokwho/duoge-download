# License scope / 许可范围

用户于 2026-10-31 明确授权正式开源游戏代码，并委托完成自动分发配置。

根目录 MIT LICENSE 适用于本项目拥有权利的程序代码：scripts/、scenes/、shaders/、addons/duoge_updater/、build_tools/、tools/blender_build/、tests/、.github/ 下的第一方代码，以及项目配置和分发配置。源码恢复记录见 docs/agent/RECOVERY-0.1.4.md。第三方代码仍适用其原有许可。

MIT 授权不自动适用于 assets/、docs/design/、人物照片/肖像、图标、模型、贴图、音乐或安装包内的全部第三方内容。人物形象已获本项目使用同意，不代表肖像权或所有美术素材被授予任意再利用权。原始/恢复素材不因程序开源而变为 CC0。

- Kenney Blocky Characters、City Kit 等素材沿用各自 CC0 许可，来源见 docs/assets-sources.md；不能将该表的 CC0 扩展到后来加入的全部素材。
- Noto 字体及补充字库沿用 SIL Open Font License，全文在 assets/fonts/OFL.txt。
- Godot Engine 沿用 MIT 许可及原引擎声明：https://godotengine.org/license/ 。Android 运行库保留原包内容，未重授其许可。
- 用户提供的两套人物模型、游戏图标及项目视觉素材保持原有权利。本项目发布和镜像既有游戏安装包，不为这些素材宣称新的第三方使用许可。

当前 Android 重建仍复用已验证旧 APK 的原生 DEX/运行库；独立 Android 更新插件的完整原始 Java/AAR 并未找回。不要把“第一方游戏代码已开源”写成“全部素材开放授权”或“原生部分完整源码已恢复”。
