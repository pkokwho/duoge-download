# 舵哥快跑第一方程序源码

本快照对应 SOURCE_COMMIT.txt 中的源码版本，程序代码采用MIT。
不包含Git历史、聊天/交接记录、私钥、人物照片、模型、贴图与字体。素材和肖像不因代码开源而改变许可，见NOTICE.md。
当前Android构建还复用旧APK原生模板，完整原生更新插件源码未恢复；不宣称这是包含所有原生依赖与美术的完整可复现包。
游戏安装包及版本说明：https://pkokwho.github.io/duoge-download/
