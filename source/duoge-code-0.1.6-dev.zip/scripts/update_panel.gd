class_name GameUpdatePanel
extends Control
const UpdateState = preload("res://scripts/app_updates.gd").State

var _service: Node
var _status: Label
var _details: Label
var _progress: ProgressBar
var _primary: Button
var _close: Button
var _dismissed_version: = -1

func setup(service: Node, game_theme: Theme) -> void :
	_service = service
	theme = game_theme
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var shade: = ColorRect.new()
	shade.color = Color(0.02, 0.06, 0.1, 0.8)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(shade)
	var panel: = PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.anchor_left = 0.065
	panel.anchor_right = 0.935
	panel.anchor_top = 0.18
	panel.anchor_bottom = 0.84
	var style: = StyleBoxFlat.new()
	style.bg_color = Color("102941")
	style.set_corner_radius_all(22)
	style.set_border_width_all(2)
	style.border_color = Color("ffd06a")
	style.content_margin_left = 26
	style.content_margin_right = 26
	style.content_margin_top = 26
	style.content_margin_bottom = 26
	panel.add_theme_stylebox_override("panel", style)
	add_child(panel)
	var box: = VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	panel.add_child(box)
	var title: = Label.new()
	title.text = "游戏更新公告"
	title.add_theme_font_size_override("font_size", 36)
	title.add_theme_color_override("font_color", Color("ffd06a"))
	box.add_child(title)
	_status = Label.new()
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.add_theme_font_size_override("font_size", 25)
	box.add_child(_status)
	var scroll: = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	box.add_child(scroll)
	_details = Label.new()
	_details.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_details.add_theme_font_size_override("font_size", 21)
	scroll.add_child(_details)
	_progress = ProgressBar.new()
	_progress.custom_minimum_size.y = 22
	_progress.show_percentage = false
	box.add_child(_progress)
	_primary = _make_button("检查更新", true)
	_primary.pressed.connect(_primary_pressed)
	box.add_child(_primary)
	_close = _make_button("稍后", false)
	_close.pressed.connect(_close_pressed)
	box.add_child(_close)
	_service.changed.connect(_refresh)
	hide()
	_refresh()

func _make_button(text: String, main: bool) -> Button:
	var button: = Button.new()
	button.text = text
	button.custom_minimum_size.y = 72
	button.add_theme_font_size_override("font_size", 26)
	var style: = StyleBoxFlat.new()
	style.bg_color = Color("ffd06a") if main else Color("1b3854")
	style.set_corner_radius_all(14)
	button.add_theme_stylebox_override("normal", style)
	button.add_theme_color_override("font_color", Color("0b1d31") if main else Color.WHITE)
	return button

func show_updates() -> void :
	show()
	_refresh()

func offer_if_new() -> void :
	if _service.state == UpdateState.AVAILABLE and int(_service.release.get("version_code", -1)) != _dismissed_version:
		show_updates()

func _refresh() -> void :
	_status.text = _service.message if not _service.message.is_empty() else "当前版本：" + _service.installed_name
	_details.text = "当前版本：" + _service.installed_name + "\n检查失败不影响游戏；更新时无需卸载旧版。"
	if _service.installed_code == _service.VERSION_CODE:
		_details.text = "当前版本：%s\n\n本版本更新公告\n%s\n\n检查失败不影响游戏。" % [_service.installed_name, _service.local_release_notes()]
	if not _service.release.is_empty():
		_details.text = "新版本：%s · %.1f MiB\n\n更新公告\n%s\n\n安装时请在安卓系统界面确认，保留游戏数据。" % [_service.release.get("version_name", ""), float(_service.release.get("size_bytes", 0)) / 1048576.0, _service.release.get("notes", "")]
	elif not _service.announcement.is_empty():
		_details.text = "当前版本：%s\n\n更新公告\n%s" % [_service.announcement.get("version_name", ""), _service.announcement.get("notes", "")]
	_progress.visible = _service.state == UpdateState.DOWNLOADING
	_progress.value = 100.0 * _service.downloaded_bytes / maxf(1.0, float(_service.release.get("size_bytes", 0)))
	_primary.disabled = false
	_close.disabled = _service.state == UpdateState.VERIFYING
	_close.text = "取消下载" if _service.state == UpdateState.DOWNLOADING else "稍后"
	if not _service.supported():
		_primary.text = "打开官网下载页"
		return
	match _service.state:
		UpdateState.CHECKING:
			_primary.text = "正在检查…"
			_primary.disabled = true
		UpdateState.AVAILABLE:
			_primary.text = "下载并更新"
		UpdateState.DOWNLOADING:
			_primary.text = "正在下载 %.1f / %.1f MB" % [_service.downloaded_bytes / 1048576.0, float(_service.release.get("size_bytes", 0)) / 1048576.0]
			_primary.disabled = true
		UpdateState.VERIFYING:
			_primary.text = "正在校验…"
			_primary.disabled = true
		UpdateState.PERMISSION:
			_primary.text = "允许安装来源并继续"
		UpdateState.READY, UpdateState.INSTALLING:
			_primary.text = "继续安装"
		UpdateState.ERROR:
			_primary.text = "重试安装" if _service.verified_download else ("重新下载" if not _service.release.is_empty() else "重新检查")
		_:
			_primary.text = "检查更新"

func _primary_pressed() -> void :
	if not _service.supported():
		OS.shell_open(_service.WEBSITE_URL)
	elif _service.state == UpdateState.PERMISSION:
		_service.request_install_permission()
	elif _service.state in [UpdateState.READY, UpdateState.INSTALLING] or (_service.state == UpdateState.ERROR and _service.verified_download):
		_service.install_downloaded()
	elif _service.state == UpdateState.AVAILABLE or (_service.state == UpdateState.ERROR and not _service.release.is_empty()):
		_service.begin_download()
	else:
		_service.check_for_updates(true)

func _close_pressed() -> void :
	if _service.state == UpdateState.VERIFYING:
		return
	_dismissed_version = int(_service.release.get("version_code", -1))
	_service.cancel_download()
	hide()
