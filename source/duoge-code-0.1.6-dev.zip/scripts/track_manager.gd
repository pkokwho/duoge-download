class_name TrackManager
extends Node3D



const SEGMENT_LENGTH: = 12.0
const LANE_X: = [-2.0, 0.0, 2.0]
const VIEW_AHEAD: = 60.0
const BEHIND: = 14.0
const START_SPEED: = 8.0
const MAX_SPEED: = 20.0
const SPEED_PER_METER: = 1.0 / 100.0
const MOVER_BACK_SPEED: = 8.0
const SAFE_ZONE: = 26.0


const TYPE_TABLE: = [
	["crate", 0.3],
	["barrier_high", 0.25],
	["barrier_slide", 0.2],
	["train_static", 0.15],
	["train_moving", 0.1],
]

const TRAIN_COLORS: = [
	Color(0.22, 0.52, 0.9),
	Color(0.95, 0.72, 0.15),
	Color(0.9, 0.32, 0.32),
	Color(0.3, 0.72, 0.5),
]

var world_speed: = START_SPEED

var _distance: = 0.0
var _movers: Array[Node3D] = []
var _rng: = RandomNumberGenerator.new()
var _building_scenes: Array[PackedScene] = []
var _deco_scenes: Array[PackedScene] = []
var _tex_asphalt: ImageTexture
var _tex_ballast: ImageTexture
var _tex_grass: ImageTexture
var _visual_pool: Array[Node3D] = []
var _visual_build_count: = 0
var _batch_root: Node3D
var _ground_batches: Dictionary = {}
var _material_cache: Dictionary = {}
var _unit_box: = BoxMesh.new()


func _ready() -> void :
	_unit_box.size = Vector3.ONE
	_rng.randomize()
	_make_textures()
	_load_buildings()
	_load_deco()
	_fill()



func _make_textures() -> void :
	_tex_asphalt = _tex_spots(Color(0.3, 0.31, 0.34), [Color(0.34, 0.35, 0.38), Color(0.26, 0.27, 0.3)], 90, 2)
	_tex_ballast = _tex_spots(Color(0.58, 0.55, 0.5), [Color(0.46, 0.43, 0.39), Color(0.68, 0.65, 0.6), Color(0.52, 0.46, 0.4)], 130, 3)
	_tex_grass = _tex_spots(Color(0.42, 0.78, 0.32), [Color(0.34, 0.68, 0.26), Color(0.5, 0.85, 0.38)], 150, 2, true)


func _tex_spots(base: Color, spot_colors: Array, count: int, spot_size: = 3, vertical: = false) -> ImageTexture:
	var img: = Image.create(64, 64, false, Image.FORMAT_RGBA8)
	img.fill(base)
	var rng: = RandomNumberGenerator.new()
	rng.seed = 12345
	for i in count:
		var c: Color = spot_colors[rng.randi_range(0, spot_colors.size() - 1)]
		var w: = rng.randi_range(1, spot_size)
		var h: = rng.randi_range(1, spot_size)
		if vertical:
			h = rng.randi_range(3, 7)
		img.fill_rect(Rect2i(rng.randi_range(0, 62), rng.randi_range(0, 62), w, h), c)
	return ImageTexture.create_from_image(img)



func _mat(color: Color, tex: Texture2D = null, uv: = Vector3.ONE, unshaded: = false) -> StandardMaterial3D:
	var key: = _material_key(color, tex, uv, unshaded)
	if _material_cache.has(key):
		return _material_cache[key]
	var m: = StandardMaterial3D.new()
	m.diffuse_mode = BaseMaterial3D.DIFFUSE_TOON
	m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	m.roughness = 1.0
	m.rim_enabled = true
	m.rim = 0.4
	m.rim_tint = 0.6
	if tex:
		m.albedo_texture = tex
		m.albedo_color = Color.WHITE
		m.uv1_scale = uv
	else:
		m.albedo_color = color
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_material_cache[key] = m
	return m


func _material_key(color: Color, tex: Texture2D, uv: Vector3, unshaded: bool) -> String:
	return str(color) + ":" + str(tex.get_rid() if tex else RID()) + ":" + str(uv) + ":" + str(unshaded)


func _load_deco() -> void :
	var base: = "res://assets/models/city-kit-roads/Models/GLB format/"
	for n in ["light-curved", "traffic-light", "electricity-pole", "construction-cone", "dumpster", "road-sign-street"]:
		var p: = load(base + n + ".glb")
		if p is PackedScene:
			_deco_scenes.append(p)


func _physics_process(delta: float) -> void :
	var move: = world_speed * delta
	_distance += move
	world_speed = minf(MAX_SPEED, START_SPEED + _distance * SPEED_PER_METER)
	for seg in get_children():
		var seg3d: = seg as Node3D
		seg3d.position.z += move
	for m in _movers:
		if is_instance_valid(m):
			m.position.z -= MOVER_BACK_SPEED * delta
	GameState.add_distance(move)
	_retire_passed_trains(delta)
	_cleanup()


func _retire_passed_trains(delta: float) -> void :
	for train in get_tree().get_nodes_in_group("train"):


		if train.global_position.z - float(train.get_meta("half_length", 6.0)) <= 0.65 or not train.visible:
			continue
		if not train.has_meta("passed_materials"):
			var unique: Dictionary = {}
			for mesh in train.find_children("*", "MeshInstance3D", true, false):
				if mesh.material_override is ShaderMaterial:
					var original: Material = mesh.material_override
					if not unique.has(original): unique[original] = original.duplicate()
					mesh.material_override = unique[original]
				elif mesh.mesh:
					for surface in mesh.mesh.get_surface_count():
						var original: Material = mesh.get_active_material(surface)
						if original is ShaderMaterial:
							if not unique.has(original): unique[original] = original.duplicate()
							mesh.set_surface_override_material(surface, unique[original])
			train.set_meta("passed_materials", unique.values())
		var opacity: = maxf(0.0, float(train.get_meta("passed_opacity", 1.0)) - delta / 0.14)
		train.set_meta("passed_opacity", opacity)
		for mat in train.get_meta("passed_materials"):
			mat.set_shader_parameter("passed_opacity", opacity)
		if opacity <= 0.0:
			train.hide()


func reset() -> void :
	for seg in get_children():
		_recycle_segment(seg)
	_movers.clear()
	world_speed = START_SPEED
	_distance = 0.0
	_fill()


func _fill() -> void :
	var far: = 0.0
	for seg in get_children():
		far = minf(far, (seg as Node3D).position.z - SEGMENT_LENGTH * 0.5)
	while far > - VIEW_AHEAD:
		var seg: = Node3D.new()
		seg.position = Vector3(0, 0, far - SEGMENT_LENGTH * 0.5)
		add_child(seg)
		var visual: Node3D
		if not _visual_pool.is_empty():
			visual = _visual_pool.pop_back()
			seg.add_child(visual)
		else:
			visual = Node3D.new()
			visual.name = "StaticVisuals"
			seg.add_child(visual)
			_build_ground(visual)
			_build_scenery(visual)
			_visual_build_count += 1
		_build_obstacles(seg)
		_build_coins(seg)
		far -= SEGMENT_LENGTH


func _cleanup() -> void :
	for seg in get_children():
		var seg3d: = seg as Node3D
		if seg3d.position.z - SEGMENT_LENGTH * 0.5 > BEHIND:
			_recycle_segment(seg3d)
	for i in range(_movers.size() - 1, -1, -1):
		var m: = _movers[i]
		if not is_instance_valid(m) or m.position.z > BEHIND:
			_movers.remove_at(i)
	_fill()


func _recycle_segment(seg: Node3D) -> void :
	var visual: = seg.get_node_or_null("StaticVisuals") as Node3D
	if visual:
		seg.remove_child(visual)
		_visual_pool.append(visual)
	remove_child(seg)
	seg.free()


func _exit_tree() -> void :

	for visual in _visual_pool:
		visual.free()
	_visual_pool.clear()


func _load_buildings() -> void :
	var base: = "res://assets/models/city-kit-commercial/Models/GLB format/"
	for n in ["building-a", "building-b", "building-c", "building-d", "building-e", "building-f",
			"building-skyscraper-a", "building-skyscraper-b", "building-skyscraper-c",
			"low-detail-building-a", "low-detail-building-b", "low-detail-building-d", "low-detail-building-f"]:
		var p: = load(base + n + ".glb")
		if p is PackedScene:
			_building_scenes.append(p)


func _build_ground(seg: Node3D) -> void :
	_batch_root = seg
	_ground_batches.clear()
	var body: = StaticBody3D.new()
	seg.add_child(body)
	var cs: = CollisionShape3D.new()
	var shape: = BoxShape3D.new()
	shape.size = Vector3(8, 0.5, SEGMENT_LENGTH)
	cs.shape = shape
	cs.position = Vector3(0, -0.25, 0)
	body.add_child(cs)

	_box(body, Vector3(8, 0.5, SEGMENT_LENGTH), Vector3(0, -0.25, 0), Color.WHITE, _tex_asphalt, Vector3(10, 14, 1))

	_box(body, Vector3(6.6, 0.08, SEGMENT_LENGTH), Vector3(0, 0.02, 0), Color.WHITE, _tex_ballast, Vector3(22, 40, 1))

	for i in 12:
		_box(body, Vector3(6.2, 0.09, 0.4), Vector3(0, 0.07, - SEGMENT_LENGTH * 0.5 + 0.5 + i), Color(0.45, 0.31, 0.2))

	for x in LANE_X:
		_box(body, Vector3(0.07, 0.12, SEGMENT_LENGTH), Vector3(x - 0.62, 0.12, 0), Color(0.42, 0.46, 0.52))
		_box(body, Vector3(0.07, 0.12, SEGMENT_LENGTH), Vector3(x + 0.62, 0.12, 0), Color(0.42, 0.46, 0.52))

	_box(body, Vector3(0.4, 0.3, SEGMENT_LENGTH), Vector3(-4.2, -0.05, 0), Color(0.9, 0.9, 0.86))
	_box(body, Vector3(0.4, 0.3, SEGMENT_LENGTH), Vector3(4.2, -0.05, 0), Color(0.9, 0.9, 0.86))
	_box(body, Vector3(10, 0.4, SEGMENT_LENGTH), Vector3(-9.4, -0.2, 0), Color.WHITE, _tex_grass, Vector3(14, 16, 1))
	_box(body, Vector3(10, 0.4, SEGMENT_LENGTH), Vector3(9.4, -0.2, 0), Color.WHITE, _tex_grass, Vector3(14, 16, 1))

	for side in [-1.0, 1.0]:
		_box(body, Vector3(0.12, 0.55, SEGMENT_LENGTH), Vector3(side * 4.6, 0.28, 0), Color(0.85, 0.87, 0.9))
		_box(body, Vector3(0.3, 0.07, SEGMENT_LENGTH), Vector3(side * 4.6, 0.52, 0), Color(0.92, 0.94, 0.96))
		_box(body, Vector3(0.3, 0.07, SEGMENT_LENGTH), Vector3(side * 4.6, 0.26, 0), Color(0.92, 0.94, 0.96))

	for i in _rng.randi_range(2, 3):
		var cloud: = Node3D.new()
		cloud.position = Vector3(_rng.randf_range(-14, 14), _rng.randf_range(10, 17), _rng.randf_range(-5, 5))
		seg.add_child(cloud)
		for j in _rng.randi_range(2, 3):
			_box(cloud, Vector3(_rng.randf_range(1.2, 2.6), 0.5, _rng.randf_range(0.8, 1.2)),
				Vector3(j * 1.1 - 1.1, _rng.randf_range(-0.15, 0.25), _rng.randf_range(-0.2, 0.2)), Color(1, 1, 1, 0.96), null, Vector3.ONE, true)
	_flush_ground_batches()


func _build_scenery(seg: Node3D) -> void :
	if _building_scenes.is_empty():
		return
	for side in [-1.0, 1.0]:
		var count: = _rng.randi_range(1, 3)
		for i in count:
			var b: Node3D = _building_scenes[_rng.randi_range(0, _building_scenes.size() - 1)].instantiate()
			b.position = Vector3(side * (9.5 + _rng.randf() * 4.0), 0, - SEGMENT_LENGTH * 0.5 + _rng.randf() * SEGMENT_LENGTH)
			b.rotation.y = _rng.randf_range(-0.35, 0.35)
			var s: = _rng.randf_range(0.8, 1.6)
			b.scale = Vector3(s, s * _rng.randf_range(0.9, 1.5), s)
			seg.add_child(b)
			_disable_scenery_shadows(b)

	if not _deco_scenes.is_empty():
		for side in [-1.0, 1.0]:
			if _rng.randf() < 0.55:
				var d: Node3D = _deco_scenes[_rng.randi_range(0, _deco_scenes.size() - 1)].instantiate()
				d.position = Vector3(side * _rng.randf_range(5.6, 8.5), 0.2, - SEGMENT_LENGTH * 0.5 + _rng.randf() * SEGMENT_LENGTH)
				d.rotation.y = _rng.randf_range(-0.6, 0.6)
				seg.add_child(d)
				_disable_scenery_shadows(d)


func _disable_scenery_shadows(node: Node3D) -> void :
	for mesh in node.find_children("*", "MeshInstance3D", true, false):
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _build_obstacles(seg: Node3D) -> void :

	if seg.position.z >= - SAFE_ZONE:
		return
	var lanes: = [0, 1, 2]
	lanes.shuffle()
	var blocked: = 1
	if GameState.score >= 80 and _rng.randf() < 0.5:
		blocked = 2
	for i in blocked:
		var type: = _pick_type(blocked)
		var ob: = ObstacleFactory.make(type)
		var z: = 0.0 if type.begins_with("train") else _rng.randf_range(-4.0, 4.0)
		ob.position = Vector3(LANE_X[lanes[i]], 0, z)
		seg.add_child(ob)
		if ob.has_meta("extra_speed"):
			_movers.append(ob)


func _pick_type(blocked: int) -> String:
	var r: = _rng.randf()
	var acc: = 0.0
	for entry in TYPE_TABLE:
		acc += entry[1]
		if r < acc:
			var t: String = entry[0]
			if t == "train_static" and blocked > 1:
				return "crate"
			if t == "train_moving" and (blocked > 1 or world_speed < 12.0):
				return "crate"
			return t
	return "crate"


func _build_coins(seg: Node3D) -> void :
	var lanes: = [0, 1, 2]
	lanes.shuffle()
	var lane: int = lanes[0]
	var blocked_lanes: = {}
	for ob in seg.get_children():
		if ob is Area3D and ob.is_in_group("obstacle"):
			var lane_i: = LANE_X.find(ob.position.x)
			if lane_i >= 0:
				blocked_lanes[lane_i] = true
	if blocked_lanes.has(lane):
		for l in lanes:
			if not blocked_lanes.has(l):
				lane = l
				break
	if blocked_lanes.has(lane):
		return
	var coin_script: = load("res://scripts/coin.gd")
	for i in 5:
		var c: Area3D = coin_script.new()
		c.position = Vector3(LANE_X[lane], 1.0, -4.0 + i * 2.0)
		seg.add_child(c)


func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, tex: Texture2D = null, uv: = Vector3.ONE, unshaded: = false) -> void :
	var key: = _material_key(color, tex, uv, unshaded)
	if not _ground_batches.has(key):
		_ground_batches[key] = {"material": _mat(color, tex, uv, unshaded), "transforms": []}
	var transform: = _batch_root.global_transform.affine_inverse() * parent.global_transform * Transform3D(Basis.from_scale(size), pos)
	_ground_batches[key]["transforms"].append(transform)


func _flush_ground_batches() -> void :
	for batch in _ground_batches.values():
		var multi: = MultiMesh.new()
		multi.transform_format = MultiMesh.TRANSFORM_3D
		multi.mesh = _unit_box
		multi.instance_count = batch["transforms"].size()
		for i in multi.instance_count:
			multi.set_instance_transform(i, batch["transforms"][i])
		var instance: = MultiMeshInstance3D.new()
		instance.multimesh = multi
		instance.material_override = batch["material"]
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_batch_root.add_child(instance)
	_ground_batches.clear()
	_batch_root = null
