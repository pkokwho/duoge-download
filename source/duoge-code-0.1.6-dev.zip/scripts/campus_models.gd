class_name CampusModels
extends RefCounted

static var _scenes: Dictionary = {}
static var _paint: ShaderMaterial
const PALETTE: = preload("res://shaders/campus_palette.gdshader")

static func make(kind: String) -> Node3D:
	if not _scenes.has(kind):
		_scenes[kind] = load("res://assets/models/campus/" + kind + ".glb")
	var node: Node3D = _scenes[kind].instantiate()
	if _paint == null:
		_paint = ShaderMaterial.new()
		_paint.shader = PALETTE
		_paint.set_shader_parameter("passed_opacity", 1.0)
	for mesh in node.find_children("*", "MeshInstance3D", true, false):
		mesh.material_override = _paint
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return node

static func obstacle(kind: String) -> Area3D:
	var area: = Area3D.new()
	area.add_to_group("obstacle")
	area.set_meta("campus_kind", kind)
	area.collision_layer = 2
	area.collision_mask = 0
	area.add_child(make(kind))
	var box: = BoxShape3D.new()
	var shape: = CollisionShape3D.new()
	match kind:
		"bus":
			box.size = Vector3(1.86, 2.6, 6.2)
			shape.position.y = 1.3
			area.add_to_group("train")
			area.set_meta("train", true)
			area.set_meta("half_length", 3.1)
		"slide":
			box.size = Vector3(1.96, 0.8, 0.3)
			shape.position.y = 1.5
		"barrier":
			box.size = Vector3(1.78, 1.0, 0.4)
			shape.position.y = 0.5
		_:
			box.size = Vector3(1.2, 0.98, 0.92)
			shape.position.y = 0.49
	shape.shape = box
	area.add_child(shape)
	return area
