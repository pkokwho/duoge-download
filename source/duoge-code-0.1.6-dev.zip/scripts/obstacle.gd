class_name ObstacleFactory
extends RefCounted



const TRAIN_COLORS: = [
	Color(0.22, 0.52, 0.9),
	Color(0.95, 0.72, 0.15),
	Color(0.9, 0.32, 0.32),
	Color(0.3, 0.72, 0.5),
]

const EXTRA_SPEED: = 8.0
const TRAIN_SHADER: = preload("res://shaders/train.gdshader")

static var _color_i: = 0
static var _train_materials: Dictionary = {}


static func make(type: String) -> Area3D:
	var area: = Area3D.new()
	if type.begins_with("train"):
		area.set_meta("train", true)
		area.add_to_group("train")
	area.add_to_group("obstacle")
	area.collision_layer = 2
	area.collision_mask = 0
	match type:
		"train_static", "train_moving":
			_build_train(area, type)
		"barrier_high":
			_build_striped_wall(area, 1.2)
		"barrier_slide":
			_build_slide_bar(area)
		"crate":
			_build_crate(area)
	var cs: = CollisionShape3D.new()
	var shape: = BoxShape3D.new()
	shape.size = _collision_size(type)
	cs.shape = shape
	cs.position = _collision_offset(type)
	area.add_child(cs)
	if type == "train_moving":
		area.set_meta("extra_speed", EXTRA_SPEED)
	return area


static func _collision_size(type: String) -> Vector3:
	match type:
		"train_static", "train_moving":
			return Vector3(2.2, 3.0, 12.0)
		"barrier_high":
			return Vector3(2.0, 1.2, 0.4)
		"barrier_slide":
			return Vector3(2.0, 0.8, 0.4)
	return Vector3(1.0, 1.0, 1.0)


static func _collision_offset(type: String) -> Vector3:
	match type:
		"train_static", "train_moving":
			return Vector3(0, 1.5, 0)
		"barrier_high":
			return Vector3(0, 0.6, 0)
		"barrier_slide":
			return Vector3(0, 1.5, 0)
	return Vector3(0, 0.5, 0)


static func _build_train(area: Area3D, type: String) -> void :
	var col: Color = TRAIN_COLORS[_color_i % TRAIN_COLORS.size()]
	_color_i += 1
	var dark: Color = col.darkened(0.35)

	_box(area, Vector3(2.2, 2.6, 11.6), Vector3(0, 1.55, 0), col)

	_box(area, Vector3(2.0, 0.2, 11.6), Vector3(0, 2.95, 0), Color(0.85, 0.86, 0.88))

	_box(area, Vector3(2.26, 0.6, 10.2), Vector3(0, 1.95, 0), Color(0.15, 0.2, 0.28))

	_box(area, Vector3(1.9, 0.8, 0.12), Vector3(0, 1.1, 5.85), Color(0.12, 0.16, 0.22))
	_box(area, Vector3(1.7, 0.25, 0.14), Vector3(0, 0.5, 5.86), Color(1.0, 0.9, 0.4))

	_box(area, Vector3(2.0, 0.3, 11.2), Vector3(0, 0.2, 0), dark)

	for i in 4:
		var z: = -4.2 + i * 2.8
		_box(area, Vector3(0.25, 0.45, 0.9), Vector3(-1.05, 0.22, z), Color(0.12, 0.12, 0.14))
		_box(area, Vector3(0.25, 0.45, 0.9), Vector3(1.05, 0.22, z), Color(0.12, 0.12, 0.14))

	for i in 3:
		_box(area, Vector3(1.0, 0.2, 1.8), Vector3(0, 3.15, -3.8 + i * 3.8), Color(0.72, 0.74, 0.78))


static func _build_striped_wall(area: Area3D, h: float) -> void :

	var bands: = 3
	var band_h: = h / bands
	for i in bands:
		var col: = Color(0.9, 0.25, 0.25) if i % 2 == 0 else Color(0.95, 0.95, 0.95)
		_box(area, Vector3(2.0, band_h, 0.4), Vector3(0, band_h * (i + 0.5), 0), col)

	_box(area, Vector3(0.18, 0.12, 0.5), Vector3(-0.8, 0.06, 0), Color(0.3, 0.3, 0.32))
	_box(area, Vector3(0.18, 0.12, 0.5), Vector3(0.8, 0.06, 0), Color(0.3, 0.3, 0.32))


static func _build_slide_bar(area: Area3D) -> void :

	for i in 2:
		var col: = Color(0.3, 0.75, 0.4) if i % 2 == 0 else Color(0.95, 0.95, 0.95)
		_box(area, Vector3(1.0, 0.8, 0.4), Vector3(-0.5 + i, 1.5, 0), col)
	_box(area, Vector3(0.12, 1.9, 0.12), Vector3(-1.05, 0.95, 0), Color(0.55, 0.58, 0.62))
	_box(area, Vector3(0.12, 1.9, 0.12), Vector3(1.05, 0.95, 0), Color(0.55, 0.58, 0.62))
	_box(area, Vector3(0.3, 0.1, 0.3), Vector3(-1.05, 0.05, 0), Color(0.4, 0.42, 0.46))
	_box(area, Vector3(0.3, 0.1, 0.3), Vector3(1.05, 0.05, 0), Color(0.4, 0.42, 0.46))


static func _build_crate(area: Area3D) -> void :

	_box(area, Vector3(1.0, 1.0, 1.0), Vector3(0, 0.5, 0), Color(0.78, 0.55, 0.3))
	_box(area, Vector3(1.06, 0.12, 1.06), Vector3(0, 0.94, 0), Color(0.6, 0.4, 0.2))
	_box(area, Vector3(1.06, 0.12, 1.06), Vector3(0, 0.06, 0), Color(0.6, 0.4, 0.2))
	_box(area, Vector3(0.12, 1.0, 1.06), Vector3(0, 0.5, 0), Color(0.66, 0.45, 0.24))


static func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> void :
	var mi: = MeshInstance3D.new()
	var bm: = BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	if parent.has_meta("train"):
		var key: = color.to_html()
		if not _train_materials.has(key):
			var train_mat: = ShaderMaterial.new()
			train_mat.shader = TRAIN_SHADER
			train_mat.set_shader_parameter("train_color", color)
			train_mat.set_shader_parameter("passed_opacity", 1.0)
			_train_materials[key] = train_mat
		mi.material_override = _train_materials[key]
		mi.position = pos
		parent.add_child(mi)
		return
	var mat: = StandardMaterial3D.new()
	mat.diffuse_mode = BaseMaterial3D.DIFFUSE_TOON
	mat.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	mat.roughness = 1.0
	mat.rim_enabled = true
	mat.rim = 0.4
	mat.rim_tint = 0.6
	mat.albedo_color = color
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
