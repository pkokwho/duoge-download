extends Node


signal score_changed(value: int)
signal coins_changed(value: int)
signal game_over(final_score: int, final_coins: int, new_record: bool)

const SAVE_PATH: = "user://highscore.cfg"
const COIN_SCORE: = 10

var score: int = 0
var coins: int = 0
var high_score: int = 0
var playing: bool = false
var mode: = "endless"
var distance: = 0.0
var _credited_distance: = 0


func _ready() -> void :
	load_high_score()


func start_run() -> void :
	score = 0
	coins = 0
	distance = 0.0
	_credited_distance = 0
	playing = true
	score_changed.emit(score)
	coins_changed.emit(coins)


func add_distance(dist: float) -> void :
	if not playing or not is_finite(dist) or dist <= 0.0:
		return
	distance += dist
	var whole: = int(floor(distance + 1e-06))
	if whole > _credited_distance:
		score += whole - _credited_distance
		_credited_distance = whole
		score_changed.emit(score)


func add_bonus(amount: int) -> void :
	if playing and amount > 0:
		score += amount
		score_changed.emit(score)


func set_mode(value: String) -> void :
	if playing or value not in ["endless", "campus_sample", "campus_sample_p2"]:
		return
	mode = value
	load_high_score()


func _score_section() -> String:
	return mode if mode in ["campus_sample", "campus_sample_p2"] else "run"


func collect_coin() -> void :
	if not playing:
		return
	coins += 1
	score += COIN_SCORE
	coins_changed.emit(coins)
	score_changed.emit(score)


func end_run() -> void :
	playing = false
	var new_record: = score > high_score
	if new_record:
		high_score = score
		save_high_score()
	game_over.emit(score, coins, new_record)


func load_high_score() -> void :
	var cfg: = ConfigFile.new()
	high_score = 0
	if cfg.load(SAVE_PATH) == OK:
		high_score = int(cfg.get_value(_score_section(), "high_score", 0))


func save_high_score() -> void :
	var cfg: = ConfigFile.new()
	cfg.load(SAVE_PATH)
	cfg.set_value(_score_section(), "high_score", high_score)
	if cfg.has_section("chars"):
		cfg.erase_section("chars")
	cfg.save(SAVE_PATH)
