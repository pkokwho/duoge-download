extends Area3D
var _collected: = false
var _base_y: = 1.1
var _time: = 0.0
func _ready() -> void :
	add_to_group("campus_magnet")
	collision_layer = 2
	collision_mask = 0
	_base_y = position.y
	var model: = CampusModels.make("magnet")
	model.scale = Vector3.ONE * 0.8
	add_child(model)
	var shape: = CollisionShape3D.new()
	var sphere: = SphereShape3D.new()
	sphere.radius = 0.65
	shape.shape = sphere
	add_child(shape)
func _process(delta: float) -> void :
	_time += delta
	rotation.y += 1.8 * delta
	position.y = _base_y + sin(_time * 3.5) * 0.09
func claim() -> bool:
	if _collected: return false
	_collected = true
	set_deferred("monitorable", false)
	hide()
	queue_free()
	return true
