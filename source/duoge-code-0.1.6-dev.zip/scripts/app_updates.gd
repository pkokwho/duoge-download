extends Node

signal changed
signal check_finished(manual: bool, available: bool)

const VERSION_CODE: = 7
const VERSION_NAME: = "0.1.6-dev"
const LOCAL_RELEASE_NOTES := "• 恢复校园建筑、树木、障碍、金币与道具的原始配色。\n• 保持场景造型、碰撞、玩法和角色动作。\n• 沿用新版图标，检查更新可查看修复公告，并保存本版本最高纪录。"
const PACKAGE_NAME: = "org.duoge.parkour"
const STANDALONE_PACKAGE_NAME := "org.duoge.parkour.standalone"
const MANIFEST_URL: = "https://pkokwho.github.io/duoge-download/update.json"
const STANDALONE_MANIFEST_URL := "https://pkokwho.github.io/duoge-download/update-standalone.json"
const WEBSITE_URL: = "https://pkokwho.github.io/duoge-download/"
const CACHE_RECORD: = "user://update_download.json"
const MAX_APK_BYTES: = 150 * 1024 * 1024

enum State{IDLE, CHECKING, CURRENT, AVAILABLE, DOWNLOADING, VERIFYING, READY, PERMISSION, INSTALLING, ERROR}
var state: = State.IDLE
var message: = ""
var release: Dictionary = {}
var announcement: Dictionary = {}
var downloaded_bytes: = 0
var installed_code: = VERSION_CODE
var installed_name: = VERSION_NAME
var verified_download: = false
var _native: Object
var _manifest_request: HTTPRequest
var _download_request: HTTPRequest
var _download_path: = ""
var _hash_thread: Thread
var _manual_check: = false
var _startup_checked: = false
var _permission_pending: = false

func _ready() -> void :
	_manifest_request = HTTPRequest.new()
	_manifest_request.timeout = 10.0
	_manifest_request.body_size_limit = 65536
	_manifest_request.max_redirects = 2
	add_child(_manifest_request)
	_manifest_request.request_completed.connect(_manifest_complete)
	_download_request = HTTPRequest.new()
	_download_request.timeout = 900.0
	_download_request.use_threads = true
	_download_request.max_redirects = 3
	add_child(_download_request)
	_download_request.request_completed.connect(_download_complete)
	if OS.has_feature("android") and Engine.has_singleton("DuogeUpdater"):
		_native = Engine.get_singleton("DuogeUpdater")
		var detected_code: = int(_native.getInstalledVersionCode())
		installed_code = detected_code if detected_code > 0 else VERSION_CODE
		installed_name = str(_native.getInstalledVersionName())
		if installed_name.is_empty():
			installed_name = VERSION_NAME
		_download_path = str(_native.getUpdateFilePath())
		_native.connect("install_permission_changed", _permission_changed)
		_native.connect("installer_status", _installer_status)
		_restore_download()
	set_process(false)

static func target_package_name() -> String:
	return str(ProjectSettings.get_setting("application/config/android_package", PACKAGE_NAME))

static func target_manifest_url() -> String:
	return STANDALONE_MANIFEST_URL if target_package_name() == STANDALONE_PACKAGE_NAME else MANIFEST_URL

static func local_release_notes() -> String:
	if target_package_name() == STANDALONE_PACKAGE_NAME:
		return LOCAL_RELEASE_NOTES + "\n\n独立新版可与旧版并存。旧版纪录保留在旧游戏中，暂不自动导入。"
	return LOCAL_RELEASE_NOTES

func supported() -> bool:
	return _native != null and not _download_path.is_empty()

func check_on_start() -> void :
	if _startup_checked or not supported():
		return
	_startup_checked = true
	check_for_updates(false)

func _set_state(value: State, text: String) -> void :
	state = value
	message = text
	set_process(state == State.DOWNLOADING)
	changed.emit()

func check_for_updates(manual: = true) -> void :
	if not supported():
		_set_state(State.ERROR, "游戏内安装更新仅在安卓安装版中提供，可从官网下载 APK。")
		check_finished.emit(manual, false)
		return
	if state in [State.CHECKING, State.DOWNLOADING, State.VERIFYING, State.READY, State.PERMISSION, State.INSTALLING]:
		changed.emit()
		return
	_manual_check = manual
	_set_state(State.CHECKING, "正在检查更新…")
	var error: = _manifest_request.request(target_manifest_url() + "?check=" + str(Time.get_unix_time_from_system()))
	if error != OK:
		_manifest_error()

static func validate_manifest(value: Variant, current_code: int, device_sdk: int) -> Dictionary:
	if not value is Dictionary:
		return {"error": "更新信息格式不正确"}
	for key in ["schema_version", "version_code", "size_bytes", "min_android_sdk"]:
		var number: Variant = value.get(key)
		if not (number is int or number is float) or not is_finite(float(number)) or number != floor(float(number)):
			return {"error": "更新信息中的数值不正确"}
	if value["schema_version"] != 1:
		return {"error": "更新信息格式不正确"}
	var code: = int(value["version_code"])
	var size: = int(value["size_bytes"])
	var sdk: = int(value["min_android_sdk"])
	if code < 1 or code > 2147483647 or size < 1 or size > MAX_APK_BYTES or sdk < 24 or sdk > 100:
		return {"error": "更新信息超出允许范围"}
	if value.get("package_name") != target_package_name():
		return {"error": "更新包不属于本游戏"}
	for key in ["version_name", "apk_url", "sha256", "notes"]:
		if not value.get(key) is String:
			return {"error": "更新信息缺少必要内容"}
	var name: String = value["version_name"]
	var notes: String = value["notes"]
	if name.is_empty() or name.length() > 40 or notes.length() > 3000:
		return {"error": "更新说明不正确"}
	var url_pattern: = RegEx.new()
	url_pattern.compile("^https://pkokwho\\.github\\.io/duoge-download/downloads/[A-Za-z0-9._-]+\\.apk$")
	if url_pattern.search(value["apk_url"]) == null:
		return {"error": "更新包下载地址不正确"}
	var hash_pattern: = RegEx.new()
	hash_pattern.compile("^[0-9a-fA-F]{64}$")
	if hash_pattern.search(value["sha256"]) == null:
		return {"error": "更新包校验信息不正确"}
	if sdk > device_sdk:
		return {"unsupported": true}
	if code < current_code:
		return {"current": true}
	var details := {"version_code": code, "version_name": name, "size_bytes": size,
		"min_android_sdk": sdk, "package_name": target_package_name(),
		"apk_url": value["apk_url"], "sha256": str(value["sha256"]).to_lower(), "notes": notes,
		"schema_version": 1}
	if code == current_code:
		return {"current": true, "announcement": details}
	return details

func _manifest_complete(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void :
	if state != State.CHECKING:
		return
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		_manifest_error()
		return
	var parsed: = validate_manifest(JSON.parse_string(body.get_string_from_utf8()), installed_code, int(_native.getAndroidSdk()))
	if parsed.has("error"):
		_set_state(State.ERROR, str(parsed["error"]) + "，可以继续游戏或稍后重试。")
	elif parsed.has("unsupported"):
		_set_state(State.CURRENT, "新版需要更高的安卓系统版本，当前游戏仍可正常游玩。")
	elif parsed.has("current"):
		release = {}
		announcement = parsed.get("announcement", {})
		_set_state(State.CURRENT, "当前已是最新版本：" + installed_name)
	else:
		release = parsed
		announcement = parsed
		_set_state(State.AVAILABLE, "发现新版本 " + str(release["version_name"]))
	check_finished.emit(_manual_check, state == State.AVAILABLE)

func _manifest_error() -> void :
	_set_state(State.ERROR, "暂时无法检查更新，可以继续游戏，稍后再试。")
	check_finished.emit(_manual_check, false)

func begin_download() -> void :
	if not supported() or release.is_empty() or state not in [State.AVAILABLE, State.ERROR]:
		return
	downloaded_bytes = 0
	verified_download = false
	_download_request.download_file = _download_path + ".part"
	_download_request.body_size_limit = int(release["size_bytes"])
	_set_state(State.DOWNLOADING, "正在下载安装包…")
	var error: = _download_request.request(str(release["apk_url"]))
	if error != OK:
		_download_error("下载无法开始，请检查网络后重试。")

func _process(_delta: float) -> void :
	if state == State.DOWNLOADING:
		var count: = _download_request.get_downloaded_bytes()
		if count != downloaded_bytes:
			downloaded_bytes = count
			changed.emit()

func cancel_download() -> void :
	if state == State.CHECKING:
		_manifest_request.cancel_request()
		_set_state(State.IDLE, "已取消检查")
	elif state == State.DOWNLOADING:
		_download_request.cancel_request()
		_remove_file(_download_path + ".part")
		_set_state(State.AVAILABLE, "已取消下载，可以稍后重试。")
	_permission_pending = false

func _download_complete(result: int, code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void :
	if state != State.DOWNLOADING:
		return
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		_download_error("下载未完成，请检查网络后重试。")
		return
	_set_state(State.VERIFYING, "下载完成，正在校验安装包…")
	_start_verification(_download_path + ".part", true)

static func verify_file(path: String, size: int, expected_hash: String) -> bool:
	var file: = FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() != size:
		return false
	file.close()
	return FileAccess.get_sha256(path).to_lower() == expected_hash

func _start_verification(path: String, new_download: bool) -> void :
	_hash_thread = Thread.new()
	var error: = _hash_thread.start(_hash_worker.bind(path, int(release["size_bytes"]), str(release["sha256"]), new_download))
	if error != OK:
		_hash_thread = null
		_download_error("暂时无法校验文件，请重试。")

func _hash_worker(path: String, size: int, expected_hash: String, new_download: bool) -> void :
	var valid: = verify_file(path, size, expected_hash)
	call_deferred("_verification_complete", valid, new_download)

func _verification_complete(valid: bool, new_download: bool) -> void :
	if _hash_thread != null:
		_hash_thread.wait_to_finish()
		_hash_thread = null
	if not valid:
		_remove_file(_download_path)
		_remove_file(CACHE_RECORD)
		_download_error("安装包校验失败，未启动安装。请重新下载。")
		return
	if new_download:
		_remove_file(_download_path)
		if DirAccess.rename_absolute(_download_path + ".part", _download_path) != OK:
			_download_error("无法保存安装包，请检查手机剩余空间。")
			return
	verified_download = true
	var record: = FileAccess.open(CACHE_RECORD, FileAccess.WRITE)
	if record:
		record.store_string(JSON.stringify(release))
	_set_state(State.READY, "安装包已校验，可以覆盖安装并保留游戏数据。")
	if new_download:
		install_downloaded()

func install_downloaded() -> void :
	if not supported() or not verified_download or state not in [State.READY, State.PERMISSION, State.INSTALLING, State.ERROR]:
		return
	var result: = str(_native.installUpdate(int(release["version_code"]), int(release["size_bytes"])))
	if result == "permission_required":
		_set_state(State.PERMISSION, "首次更新需要允许“舵哥快跑”安装应用。授权后返回游戏，将继续打开系统安装界面。")
	elif result == "launching":
		_set_state(State.INSTALLING, "请在安卓系统安装界面确认。若取消，可以回来再次安装。")
	else:
		if result in ["file_invalid", "signature_mismatch", "package_mismatch", "version_mismatch"]:
			verified_download = false
		_set_state(State.ERROR, _native_error(result))

func request_install_permission() -> void :
	if state == State.PERMISSION and supported():
		_permission_pending = true
		_native.requestInstallPermission()

func _permission_changed(allowed: bool) -> void :
	if _permission_pending:
		_permission_pending = false
		if allowed:
			install_downloaded()
		else:
			_set_state(State.PERMISSION, "尚未允许安装来源。你可以重新授权，也可以稍后更新。")

func _installer_status(value: String) -> void :
	if value == "opened":
		_set_state(State.INSTALLING, "已打开系统安装界面，请确认安装；无需卸载旧版本。")
	else:
		_permission_pending = false
		_set_state(State.ERROR, _native_error(value))

func _native_error(value: String) -> String:
	match value:
		"package_mismatch": return "安装包不属于本游戏，已拒绝安装。"
		"signature_mismatch": return "安装包签名与当前游戏不一致，已拒绝安装。"
		"version_mismatch": return "安装包版本不正确，已拒绝安装。"
		"android_too_old": return "当前安卓系统不满足新版要求。"
		"file_invalid": return "安装包无效，请重新下载。"
		"permission_settings_failed": return "无法打开授权设置，可稍后重试或从官网下载。"
		_: return "无法打开系统安装界面，可重试或从官网下载。"

func _restore_download() -> void :
	if not FileAccess.file_exists(CACHE_RECORD):
		return
	var file: = FileAccess.open(CACHE_RECORD, FileAccess.READ)
	if file == null or file.get_length() > 65536:
		return
	var saved: = validate_manifest(JSON.parse_string(file.get_as_text()), installed_code, int(_native.getAndroidSdk()))
	if saved.has("version_code") and FileAccess.file_exists(_download_path):
		release = saved
		_set_state(State.VERIFYING, "正在校验此前下载的更新…")
		_start_verification(_download_path, false)
	else:
		_remove_file(CACHE_RECORD)
		_remove_file(_download_path)

func _download_error(text: String) -> void :
	_remove_file(_download_path + ".part")
	_set_state(State.ERROR, text)

func _remove_file(path: String) -> void :
	if not path.is_empty() and FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func _exit_tree() -> void :
	_manifest_request.cancel_request()
	_download_request.cancel_request()
	if _hash_thread != null and _hash_thread.is_started():
		_hash_thread.wait_to_finish()
