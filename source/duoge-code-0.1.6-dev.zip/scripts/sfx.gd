extends Node



const RATE: = 44100

var _streams: = {}
var _last_coin_ms: = -1000


func _ready() -> void :
	_streams["jump"] = _tone(320.0, 660.0, 0.18, 0.42, "sine")
	_streams["land"] = _thud()
	_streams["coin"] = _coin()
	_streams["slide"] = _noise(0.24, 0.28, 1500.0)
	_streams["crash"] = _crash()
	_streams["click"] = _tone(520.0, 520.0, 0.06, 0.25, "square")


func play(name: String, volume_db: = -3.0) -> void :
	if DisplayServer.get_name() == "headless": return
	if not _streams.has(name):
		return


	if name == "coin":
		var now: = Time.get_ticks_msec()
		if now - _last_coin_ms < 35: return
		_last_coin_ms = now
	if get_child_count() >= 12: return
	var p: = AudioStreamPlayer.new()
	p.stream = _streams[name]
	p.volume_db = volume_db
	p.finished.connect(p.queue_free)
	add_child(p)
	p.play()


func _exit_tree() -> void :
	for child in get_children():
		if child is AudioStreamPlayer:
			child.stop()
			child.stream = null
	_streams.clear()


func _wav(data: PackedByteArray) -> AudioStreamWAV:
	var w: = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	return w



func _tone(f0: float, f1: float, dur: float, gain: float, wave: = "sine") -> AudioStreamWAV:
	var n: = int(dur * RATE)
	var data: = PackedByteArray()
	data.resize(n * 2)
	var phase: = 0.0
	for i in n:
		var t: = float(i) / n
		var f: = lerpf(f0, f1, t)
		phase += TAU * f / RATE
		var s: = sin(phase)
		if wave == "square":
			s = signf(s) * 0.5
		var env: = minf(t * 30.0, 1.0) * (1.0 - t)
		data.encode_s16(i * 2, int(clampf(s * env * gain, -1.0, 1.0) * 32767.0))
	return _wav(data)



func _noise(dur: float, gain: float, cutoff: = 1200.0) -> AudioStreamWAV:
	var n: = int(dur * RATE)
	var data: = PackedByteArray()
	data.resize(n * 2)
	var rng: = RandomNumberGenerator.new()
	rng.seed = 7
	var y: = 0.0
	var a: = 1.0 - exp( - TAU * cutoff / RATE)
	for i in n:
		var t: = float(i) / n
		y += a * (rng.randf_range(-1.0, 1.0) - y)
		var env: = (1.0 - t) * (1.0 - t)
		data.encode_s16(i * 2, int(clampf(y * env * gain, -1.0, 1.0) * 32767.0))
	return _wav(data)



func _thud() -> AudioStreamWAV:
	var a: = _tone(150.0, 60.0, 0.1, 0.5, "sine")
	a.data += _noise(0.06, 0.16, 500.0).data
	return a



func _coin() -> AudioStreamWAV:
	var a: = _tone(988.0, 988.0, 0.07, 0.3, "square")
	a.data += _tone(1319.0, 1319.0, 0.16, 0.3, "square").data
	return a



func _crash() -> AudioStreamWAV:
	var w: = _noise(0.4, 0.55, 800.0)
	var d: = w.data
	var m: = d.size() / 2
	var phase: = 0.0
	for i in m:
		var t: = float(i) / m
		var f: = lerpf(110.0, 45.0, t)
		phase += TAU * f / RATE
		var saw: = fposmod(phase / TAU, 1.0) * 2.0 - 1.0
		var v: = d.decode_s16(i * 2) + int(saw * (1.0 - t) * 0.35 * 32767.0)
		d.encode_s16(i * 2, clampi(v, -32768, 32767))
	w.data = d
	return w
