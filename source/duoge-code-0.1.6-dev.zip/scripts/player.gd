class_name Player
extends CharacterBody3D




signal died

const LANE_WIDTH: = 2.0
const LANE_LERP: = 16.0
const JUMP_VELOCITY: = 9.0
const RISE_GRAVITY: = 24.0
const FALL_GRAVITY: = 30.0
const FAST_FALL: = -20.0
const SLIDE_TIME: = 0.75
const STAND_HEIGHT: = 1.8
const SLIDE_HEIGHT: = 0.9
const SWIPE_MIN: = 24.0
const SWIPE_SCREEN_FRACTION: = 0.035
const GROUND_Y: = 0.95
const BUFFER_TIME: = 0.15
const MODEL_RUNNER: = "res://assets/models/teacher/teacher_runner.glb"
const REQUIRED_CLIPS: = ["Idle", "Run", "Jump", "Slide"]

var lane: = 0
var sliding: = false
var slide_timer: = 0.0
var alive: = true
var run_speed: = 8.0

var _visual: Node3D
var _skel: Skeleton3D
var _animation_player: AnimationPlayer
var _animation_names: Dictionary = {}
var _current_clip: = ""
var _squash: = 0.0
var _jump_buffer: = 0.0
var _slide_pending: = false
var _was_on_floor: = true
var _dead: = false
var _shape: CapsuleShape3D
var _swipe_start: = Vector2.INF
var _touch_index: = -1
var _mouse_down: = false
var _swipe_consumed: = false

@onready var _collision: CollisionShape3D = $CollisionShape3D
@onready var _hurt_shape: CollisionShape3D = $Hurtbox / HurtShape


func _ready() -> void :
	_shape = _collision.shape as CapsuleShape3D
	_build_visual()
	_build_gold_effect()
	$Hurtbox.area_entered.connect(_on_hurtbox_area_entered)



func _build_gold_effect() -> void :

	var ring: = MeshInstance3D.new()
	var torus: = TorusMesh.new()
	torus.inner_radius = 0.3
	torus.outer_radius = 0.4
	var rmat: = StandardMaterial3D.new()
	rmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rmat.albedo_color = Color(1.0, 0.82, 0.25)
	rmat.emission_enabled = true
	rmat.emission = Color(1.0, 0.78, 0.2)
	rmat.emission_energy_multiplier = 1.6
	ring.mesh = torus
	ring.material_override = rmat
	ring.position = Vector3(0, 0.04, 0)
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ring)

	var lamp: = OmniLight3D.new()
	lamp.light_color = Color(1.0, 0.85, 0.45)
	lamp.light_energy = 1.1
	lamp.omni_range = 2.4
	lamp.position = Vector3(0, 1.0, 0.5)
	lamp.shadow_enabled = false
	add_child(lamp)


func _physics_process(delta: float) -> void :
	if not alive:
		return
	_jump_buffer = maxf(0.0, _jump_buffer - delta)
	if not is_on_floor():
		velocity.y -= (RISE_GRAVITY if velocity.y > 0.0 else FALL_GRAVITY) * delta
	if Input.is_action_just_pressed("move_left"):
		move_lane(-1)
	elif Input.is_action_just_pressed("move_right"):
		move_lane(1)
	elif Input.is_action_just_pressed("jump"):
		if is_on_floor():
			if sliding:
				_end_slide()
				_spawn_dust()
			jump()
		else:
			_jump_buffer = BUFFER_TIME
	elif Input.is_action_just_pressed("slide"):
		if is_on_floor():
			start_slide()
		else:
			velocity.y = minf(velocity.y, FAST_FALL)
			_slide_pending = true
	if sliding:
		slide_timer -= delta
		if slide_timer <= 0.0:
			_end_slide()
	if is_on_floor():
		if _jump_buffer > 0.0 and not sliding:
			_jump_buffer = 0.0
			jump()
		if _slide_pending and not sliding:
			_slide_pending = false
			start_slide()
	position.x = lerpf(position.x, lane * LANE_WIDTH, minf(LANE_LERP * delta, 1.0))
	if position.y < -5.0:
		die()
	move_and_slide()
	if is_on_floor() and not _was_on_floor:
		_squash = 1.0
		_spawn_dust()
		Sfx.play("land")
	_was_on_floor = is_on_floor()


func _process(delta: float) -> void :
	if _visual == null or _dead:
		return
	_animate(delta)


func _unhandled_input(event: InputEvent) -> void :
	if not alive or not is_physics_processing():
		return
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			_touch_index = event.index
			_swipe_start = event.position
			_swipe_consumed = false
		elif not event.pressed and event.index == _touch_index:
			if not event.canceled:
				_try_swipe(event.position)
			_reset_pointer()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		_try_swipe(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:


		if event.device == InputEvent.DEVICE_ID_EMULATION or _touch_index != -1:
			return
		if event.pressed:
			_mouse_down = true
			_swipe_start = event.position
			_swipe_consumed = false
		elif _mouse_down:
			_try_swipe(event.position)
			_reset_pointer()
	elif event is InputEventMouseMotion and _mouse_down:
		_try_swipe(event.position)


func _swipe_threshold() -> float:
	var size: = get_viewport().get_visible_rect().size
	return maxf(SWIPE_MIN, minf(size.x, size.y) * SWIPE_SCREEN_FRACTION)


func _try_swipe(at: Vector2) -> void :
	if _swipe_consumed or _swipe_start.x == INF:
		return
	var movement: = at - _swipe_start
	if movement.length() >= _swipe_threshold():
		_swipe_consumed = true
		_handle_swipe(movement)


func _reset_pointer() -> void :
	_swipe_start = Vector2.INF
	_touch_index = -1
	_mouse_down = false
	_swipe_consumed = false


func _handle_swipe(d: Vector2) -> void :
	if d.length() < _swipe_threshold():
		return
	if absf(d.x) > absf(d.y):
		move_lane(1 if d.x > 0.0 else -1)
	elif d.y < 0.0:
		if is_on_floor():
			if sliding:
				_end_slide()
				_spawn_dust()
			jump()
		else:
			_jump_buffer = BUFFER_TIME
	else:
		if is_on_floor():
			start_slide()
		else:
			velocity.y = minf(velocity.y, FAST_FALL)
			_slide_pending = true


func move_lane(dir: int) -> void :
	lane = clampi(lane + dir, -1, 1)


func jump() -> void :
	if is_on_floor() and not sliding:
		velocity.y = JUMP_VELOCITY
		Sfx.play("jump")


func start_slide() -> void :
	if not is_on_floor() or sliding:
		return
	sliding = true
	slide_timer = SLIDE_TIME
	_set_height(SLIDE_HEIGHT)
	_spawn_dust()
	Sfx.play("slide")


func reset_run() -> void :
	_reset_pointer()
	alive = true
	_dead = false
	lane = 0
	sliding = false
	slide_timer = 0.0
	_jump_buffer = 0.0
	_slide_pending = false
	_squash = 0.0
	velocity = Vector3.ZERO
	position = Vector3(0, GROUND_Y, 0)
	_set_height(STAND_HEIGHT)
	_visual.rotation = Vector3.ZERO
	_visual.scale = Vector3.ONE
	_visual.position = Vector3.ZERO
	_current_clip = ""
	_play_clip("Idle")


func die() -> void :
	if not alive:
		return
	alive = false
	_reset_pointer()
	_dead = true
	if _animation_player:
		_animation_player.pause()
	Sfx.play("crash")
	velocity = Vector3.ZERO
	var tw: = create_tween()
	tw.set_parallel(true)
	tw.tween_property(self, "position:y", position.y + 0.55, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_visual, "rotation:x", -1.35, 0.45).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.chain().tween_property(self, "position:y", 0.35, 0.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	died.emit()


func _end_slide() -> void :
	sliding = false
	_set_height(STAND_HEIGHT)


func _set_height(h: float) -> void :
	_shape.height = h
	_collision.position.y = h * 0.5
	_hurt_shape.position.y = h * 0.5


func _spawn_dust() -> void :
	var p: = CPUParticles3D.new()
	p.amount = 12
	p.lifetime = 0.45
	p.one_shot = true
	p.explosiveness = 0.9
	p.direction = Vector3(0, 1, 0)
	p.spread = 70.0
	p.initial_velocity_min = 1.2
	p.initial_velocity_max = 2.6
	p.gravity = Vector3(0, -7.0, 0)
	var m: = SphereMesh.new()
	m.radius = 0.09
	m.height = 0.18
	m.radial_segments = 6
	m.rings = 3
	var mat: = StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.88, 0.85, 0.8, 0.9)
	m.material = mat
	p.mesh = m
	p.position = Vector3(0, 0.08, 0.12)
	add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func _on_hurtbox_area_entered(area: Area3D) -> void :
	if not alive:
		return
	if area.is_in_group("coin"):
		if area.has_method("try_collect"):
			area.try_collect()
		else:
			GameState.collect_coin()
			if area.has_method("collect"):
				area.collect()
			else:
				area.queue_free()
	elif area.is_in_group("obstacle"):
		die()




func _build_visual() -> void :
	_visual = Node3D.new()
	add_child(_visual)
	var packed: = load(MODEL_RUNNER) as PackedScene
	if packed == null:
		push_error("Runner model could not be loaded: " + MODEL_RUNNER)
		return
	var inst: = packed.instantiate() as Node3D
	inst.rotation.y = PI
	_visual.add_child(inst)
	for mesh in inst.find_children("*", "MeshInstance3D", true, false):
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	var skeletons: = inst.find_children("*", "Skeleton3D", true, false)
	var players: = inst.find_children("*", "AnimationPlayer", true, false)
	if skeletons.is_empty() or players.is_empty():
		push_error("Runner model must contain a Skeleton3D and AnimationPlayer")
		return
	_skel = skeletons[0]
	_animation_player = players[0]
	for wanted in REQUIRED_CLIPS:
		for imported in _animation_player.get_animation_list():
			if imported == wanted or imported.ends_with("/" + wanted) or imported.ends_with("|" + wanted):
				_animation_names[wanted] = imported
				break
		if not _animation_names.has(wanted):
			push_error("Runner animation missing: " + wanted)
			continue
		var animation: = _animation_player.get_animation(_animation_names[wanted])
		animation.loop_mode = Animation.LOOP_LINEAR if wanted in ["Idle", "Run"] else Animation.LOOP_NONE
	_play_clip("Idle")


func _play_clip(name: String, speed: = 1.0) -> void :
	if _animation_player == null or not _animation_names.has(name):
		return
	_animation_player.speed_scale = speed
	if _current_clip == name:
		return
	_current_clip = name
	_animation_player.play(_animation_names[name], 0.1)


func _animate(delta: float) -> void :
	_squash = maxf(0.0, _squash - delta * 5.0)
	_visual.scale = Vector3(1.0 + _squash * 0.18, 1.0 - _squash * 0.25, 1.0 + _squash * 0.18)
	var lean: = clampf((position.x - lane * LANE_WIDTH) * 0.28, -0.5, 0.5)
	_visual.rotation.z = lerp_angle(_visual.rotation.z, lean, minf(12.0 * delta, 1.0))
	if not is_physics_processing():
		_play_clip("Idle")
	elif sliding:
		_play_clip("Slide")
	elif not is_on_floor():
		_play_clip("Jump")
	else:
		_play_clip("Run", clampf(run_speed / 8.0, 1.0, 1.65))
