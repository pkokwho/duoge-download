extends Node3D


const PLAYER_SCENE: = preload("res://scenes/player.tscn")

var player: Player
var track: TrackManager
var cam: Camera3D
var ui: CanvasLayer
var ui_root: Control
var update_panel: GameUpdatePanel
var update_button: Button
var settings_button: Button
var settings_screen: Control
var settings_version_label: Label
var menu_version_label: Label
var ui_theme: Theme
var hud: Control
var score_label: Label
var coin_label: Label
var start_screen: Control
var start_high_label: Label
var over_screen: Control
var over_score_label: Label
var over_high_label: Label
var over_coin_label: Label
var over_title_label: Label
var record_label: Label
var speed_label: Label
var hint_panel: Panel
var _hint_seen: = false
var playing: = false
var _shake: = 0.0
var flash: ColorRect
var loading_screen: Control
var loading_bar: ProgressBar
var loading_logo: TextureRect
var _logo_t: = 0.0

const NAVY: = Color("0b1d31")
const GOLD: = Color("ffd06a")
const WHITE: = Color("f8fbff")
const CAMERA_HEIGHT: = 4.8
const CAMERA_DISTANCE: = 4.0
const CAMERA_FOV: = 65.0
const CAMERA_FOLLOW: = 0.65


func _ready() -> void :
	_build_environment()
	_build_skyline()
	track = _make_track()
	track.name = "TrackManager"
	add_child(track)
	player = PLAYER_SCENE.instantiate()
	player.name = "Player"
	player.position = Vector3(0, Player.GROUND_Y, 0)
	add_child(player)
	player.died.connect(_on_player_died)
	cam = Camera3D.new()

	cam.keep_aspect = Camera3D.KEEP_HEIGHT
	cam.fov = CAMERA_FOV
	cam.position = Vector3(0, CAMERA_HEIGHT, CAMERA_DISTANCE)
	add_child(cam)
	cam.make_current()
	_build_ui()
	Updates.check_finished.connect(_update_check_finished)
	Updates.changed.connect(_update_button_status)
	get_viewport().size_changed.connect(_update_safe_area)
	_update_safe_area()
	_run_loading()
	GameState.game_over.connect(_on_game_over)
	if "--smoke" in OS.get_cmdline_user_args():
		_run_smoke()


func _make_track() -> TrackManager:
	return TrackManager.new()


func _process(delta: float) -> void :
	if cam == null:
		return

	if loading_screen != null and loading_screen.visible:
		_logo_t += delta
		loading_logo.pivot_offset = loading_logo.size * 0.5
		loading_logo.scale = Vector2.ONE * (1.0 + sin(_logo_t * 7.0) * 0.04)
	if start_screen != null and start_screen.visible and not playing:
		return
	_update_camera(delta)
	if track and player:
		player.run_speed = track.world_speed
		if playing:
			speed_label.text = "◆  速度 ×%.1f" % (track.world_speed / TrackManager.START_SPEED)

	if _shake > 0.0:
		_shake = maxf(0.0, _shake - delta * 1.1)
		cam.h_offset = randf_range(-1.0, 1.0) * _shake * 0.3
		cam.v_offset = randf_range(-1.0, 1.0) * _shake * 0.3
	else:
		cam.h_offset = 0.0
		cam.v_offset = 0.0


func _update_camera(delta: float, snap: = false) -> void :
	var view: = get_viewport().get_visible_rect().size
	if view.x <= 0 or view.y <= 0:
		return
	var aspect: = view.x / view.y


	cam.fov = maxf(CAMERA_FOV, rad_to_deg(2.0 * atan(tan(deg_to_rad(15.0)) / aspect)))
	var safe: = ui_root.get_global_rect() if ui_root else Rect2(Vector2.ZERO, view)
	var root_y: = (safe.position.y + safe.size.y * 0.85) / view.y
	var half_tan: = tan(deg_to_rad(cam.fov * 0.5))
	var pitch: = atan2(CAMERA_HEIGHT, CAMERA_DISTANCE) - atan((root_y - 0.5) * 2.0 * half_tan)
	cam.position.y = CAMERA_HEIGHT
	cam.position.z = CAMERA_DISTANCE
	cam.rotation = Vector3( - pitch, 0, 0)
	var target_x: = player.position.x * CAMERA_FOLLOW
	cam.position.x = target_x if snap else lerpf(cam.position.x, target_x, 1.0 - exp(-14.0 * delta))


	if player._skel and player.visible:
		var lo: = - INF
		var hi: = INF
		var margin: = 16.0
		var left: = (safe.position.x + margin - view.x * 0.5) / (view.x * 0.5)
		var right: = (safe.end.x - margin - view.x * 0.5) / (view.x * 0.5)
		for bone in player._skel.get_bone_count():
			var point: Vector3 = player._skel.global_transform * player._skel.get_bone_global_pose(bone).origin
			var depth: float = - (cam.global_basis.inverse() * (point - cam.global_position)).z
			var pad: = 0.25 if player._skel.get_bone_name(bone) == "head" else 0.16
			lo = maxf(lo, point.x + pad - right * depth * half_tan * aspect)
			hi = minf(hi, point.x - pad - left * depth * half_tan * aspect)
		if lo <= hi:
			cam.position.x = clampf(cam.position.x, lo, hi)


func _start_game() -> void :
	settings_screen.hide()
	GameState.start_run()
	track.visible = true
	player.set_physics_process(true)
	track.set_physics_process(true)
	track.reset()
	player.reset_run()
	player.rotation.y = 0.0
	player.visible = true
	_update_camera(0.0, true)
	Engine.time_scale = 1.0
	start_screen.hide()
	over_screen.hide()
	hud.show()
	hint_panel.visible = not _hint_seen
	if not _hint_seen:
		_hint_seen = true
		get_tree().create_timer(4.0).timeout.connect( func() -> void :
			if is_instance_valid(hint_panel):
				hint_panel.hide())
	playing = true


func _show_start() -> void :
	settings_screen.hide()
	playing = false
	start_high_label.text = _format_score(GameState.high_score)
	start_screen.show()
	over_screen.hide()
	hud.hide()
	player.reset_run()
	player.position = Vector3(0, Player.GROUND_Y, 0)
	player.visible = false
	track.visible = false
	player.set_physics_process(false)
	track.set_physics_process(false)
	for l3d in get_tree().root.find_children("*", "Label3D", true, false):
		l3d.queue_free()
	Updates.check_on_start()
	update_panel.offer_if_new()


func _update_check_finished(manual: bool, available: bool) -> void :
	if manual:
		update_panel.show_updates()
	elif available and not playing and start_screen.visible:
		update_panel.offer_if_new()


func _update_button_status() -> void :
	if update_button == null:
		return
	update_button.text = "有新版本 · 检查更新" if Updates.state == Updates.State.AVAILABLE else "检查更新"
	settings_button.text = "设置 · 新版本" if Updates.state == Updates.State.AVAILABLE else "设置"
	settings_version_label.text = "当前版本：" + Updates.installed_name
	menu_version_label.text = "v" + Updates.installed_name


func _open_settings() -> void :
	if playing:
		return
	_update_button_status()
	settings_screen.show()


func _unhandled_input(event: InputEvent) -> void :
	if event.is_action_pressed("ui_cancel") and settings_screen and settings_screen.visible:
		if update_panel.visible:
			update_panel._close_pressed()
		else:
			settings_screen.hide()
		get_viewport().set_input_as_handled()


func _on_player_died() -> void :
	if not playing:
		return
	playing = false
	_shake = 0.55
	flash.color.a = 0.32
	var tw: = create_tween()
	tw.tween_property(flash, "color:a", 0.0, 0.45)
	Engine.time_scale = 0.25
	GameState.end_run()


func _on_game_over(final_score: int, final_coins: int, new_record: bool) -> void :
	over_score_label.text = _format_score(final_score)
	over_high_label.text = _format_score(GameState.high_score)
	over_coin_label.text = str(final_coins)
	over_title_label.text = "新纪录！" if new_record else "挑战结束"
	record_label.visible = new_record
	await get_tree().create_timer(0.5, true, false, true).timeout
	Engine.time_scale = 1.0
	hud.hide()
	over_screen.show()


func _build_environment() -> void :
	var we: = WorldEnvironment.new()
	var env: = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky: = Sky.new()
	var mat: = ProceduralSkyMaterial.new()
	mat.sky_top_color = Color(0.22, 0.52, 0.95)
	mat.sky_horizon_color = Color(0.85, 0.92, 0.98)
	mat.ground_bottom_color = Color(0.45, 0.52, 0.45)
	mat.ground_horizon_color = Color(0.85, 0.92, 0.98)
	mat.sun_angle_max = 12.0
	sky.sky_material = mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.42
	env.glow_enabled = false
	env.fog_enabled = false
	env.fog_light_color = Color(0.85, 0.92, 0.98)
	env.fog_density = 0.008
	env.fog_sky_affect = 0.1
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC

	env.adjustment_enabled = true
	env.adjustment_brightness = 0.79
	env.adjustment_contrast = 1.04
	env.adjustment_saturation = 1.1
	we.environment = env
	add_child(we)

	var sun: = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-46, -32, 0)
	sun.light_color = Color(1.0, 0.95, 0.82)
	sun.light_energy = 0.9
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 24.0
	add_child(sun)


func _build_ui() -> void :
	ui = CanvasLayer.new()
	add_child(ui)
	ui_root = Control.new()
	ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(ui_root, ui, 0, 0, 1, 1)
	ui_theme = Theme.new()
	ui_theme.default_font = load("res://assets/fonts/NotoSansCJKsc-GameSubset.otf")
	ui_theme.default_font_size = 28


	start_screen = _make_screen()
	var bg: = TextureRect.new()
	bg.texture = load("res://assets/ui/menu-bg.jpg")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_place(bg, start_screen, 0, 0, 1, 1)
	_color(start_screen, Color(0.025, 0.075, 0.14, 0.37), 0, 0, 1, 1)
	var hero: = TextureRect.new()
	hero.texture = load("res://assets/ui/duoge-hero.png")
	hero.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	hero.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hero.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(hero, start_screen, 0.04, 0.23, 0.96, 0.82)
	_color(start_screen, Color(0.025, 0.07, 0.13, 0.66), 0, 0.82, 1, 1)
	var brand: = _label("━━  马眼工作室", 22, WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_place(brand, start_screen, 0.055, 0.034, 0.62, 0.07)
	settings_button = _button("设置", 28, GOLD, Color(NAVY, 0.94), false)
	_place(settings_button, start_screen, 0.69, 0.032, 0.945, 0.105)
	settings_button.pressed.connect(_open_settings)
	var title_top: = _label("舵哥", 104, WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_place(title_top, start_screen, 0.055, 0.12, 0.75, 0.22)
	var title_bottom: = _label("快跑", 104, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
	_place(title_bottom, start_screen, 0.055, 0.205, 0.75, 0.305)
	var tagline: = _label("都市冲刺  ·  无限跑酷", 24, WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_place(tagline, start_screen, 0.06, 0.303, 0.8, 0.34)
	var mode: = _panel(start_screen, 0.055, 0.805, 0.47, 0.845, Color(NAVY, 0.88), 20, Color(GOLD, 0.4))
	var mode_label: = _label("◆  急速奔跑  ·  舵哥", 21, WHITE)
	_place(mode_label, mode, 0, 0, 1, 1)
	menu_version_label = _label("v" + Updates.installed_name, 21, GOLD, HORIZONTAL_ALIGNMENT_RIGHT)
	_place(menu_version_label, start_screen, 0.52, 0.805, 0.945, 0.845)
	var best_caption: = _label("最高纪录", 20, Color(WHITE, 0.82), HORIZONTAL_ALIGNMENT_LEFT)
	_place(best_caption, start_screen, 0.06, 0.855, 0.32, 0.89)
	start_high_label = _label("0", 36, WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	_place(start_high_label, start_screen, 0.4, 0.847, 0.94, 0.895)
	var play_btn: = _button("开始奔跑       →", 43, NAVY, GOLD)
	_place(play_btn, start_screen, 0.055, 0.9, 0.945, 0.962)
	play_btn.pressed.connect(_start_game)
	play_btn.pressed.connect( func() -> void : Sfx.play("click"))
	var help: = _label("左右滑动换道  ·  上滑跳跃  ·  下滑滑铲", 18, Color(WHITE, 0.78))
	_place(help, start_screen, 0.04, 0.969, 0.96, 0.994)


	hud = _make_screen()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var score_card: = _panel(hud, 0.026, 0.025, 0.535, 0.112, Color(NAVY, 0.9), 18, Color(WHITE, 0.18))
	var score_caption: = _label("本局得分", 19, Color(WHITE, 0.7), HORIZONTAL_ALIGNMENT_LEFT)
	_place(score_caption, score_card, 0.06, 0.07, 0.92, 0.4)
	score_label = _label("0", 53, WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_place(score_label, score_card, 0.055, 0.35, 0.95, 0.98)
	var coin_card: = _panel(hud, 0.55, 0.025, 0.974, 0.112, Color(NAVY, 0.9), 18, Color(WHITE, 0.18))
	var coin_caption: = _label("金币", 19, Color(WHITE, 0.7), HORIZONTAL_ALIGNMENT_LEFT)
	_place(coin_caption, coin_card, 0.06, 0.07, 0.94, 0.4)
	coin_label = _label("◯ 0", 49, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
	_place(coin_label, coin_card, 0.06, 0.35, 0.94, 0.98)
	var speed_card: = _panel(hud, 0.025, 0.125, 0.31, 0.161, Color(NAVY, 0.82), 14)
	speed_label = _label("◆  速度 ×1.0", 20, WHITE)
	_place(speed_label, speed_card, 0, 0, 1, 1)
	hint_panel = _panel(hud, 0.08, 0.18, 0.92, 0.225, Color(NAVY, 0.9), 15)
	var hint: = _label("左右滑动换道  ·  上滑跳跃  ·  下滑滑铲", 20, WHITE)
	_place(hint, hint_panel, 0, 0, 1, 1)
	hint_panel.hide()


	over_screen = _make_screen()
	_color(over_screen, Color(NAVY, 0.68), 0, 0, 1, 1)
	var result_brand: = _label("舵哥快跑", 28, WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_place(result_brand, over_screen, 0.055, 0.04, 0.49, 0.09)
	var result_eyebrow: = _label("RUN COMPLETE", 17, Color(WHITE, 0.72), HORIZONTAL_ALIGNMENT_RIGHT)
	_place(result_eyebrow, over_screen, 0.55, 0.046, 0.945, 0.08)
	var card: = _panel(over_screen, 0.065, 0.205, 0.935, 0.825, Color("102941"), 22, Color(GOLD, 0.28))
	var personal: = _label("P E R S O N A L   B E S T", 17, GOLD)
	_place(personal, card, 0.08, 0.07, 0.92, 0.12)
	over_title_label = _label("挑战结束", 56, WHITE)
	_place(over_title_label, card, 0.08, 0.12, 0.92, 0.25)
	_color(card, Color(GOLD, 0.62), 0.1, 0.29, 0.9, 0.293)
	var score_small: = _label("本局得分", 23, Color(WHITE, 0.78))
	_place(score_small, card, 0.1, 0.33, 0.9, 0.39)
	over_score_label = _label("0", 91, GOLD)
	_place(over_score_label, card, 0.05, 0.395, 0.95, 0.55)
	record_label = _label("◆  刷新个人最佳成绩  ◆", 22, GOLD)
	_place(record_label, card, 0.16, 0.565, 0.84, 0.625)
	record_label.hide()
	_color(card, Color(WHITE, 0.17), 0.1, 0.665, 0.9, 0.668)
	var best_small: = _label("最高纪录", 19, Color(WHITE, 0.67))
	_place(best_small, card, 0.1, 0.7, 0.49, 0.75)
	var coins_small: = _label("本局金币", 19, Color(WHITE, 0.67))
	_place(coins_small, card, 0.51, 0.7, 0.9, 0.75)
	over_high_label = _label("0", 29, WHITE)
	_place(over_high_label, card, 0.1, 0.755, 0.49, 0.81)
	over_coin_label = _label("0", 29, WHITE)
	_place(over_coin_label, card, 0.51, 0.755, 0.9, 0.81)
	var again_btn: = _button("再来一局       →", 35, NAVY, GOLD)
	_place(again_btn, card, 0.07, 0.855, 0.93, 0.945)
	again_btn.pressed.connect(_start_game)
	again_btn.pressed.connect( func() -> void : Sfx.play("click"))
	var home_btn: = _button("返回首页", 23, WHITE, Color(WHITE, 0.01), false)
	_place(home_btn, over_screen, 0.28, 0.848, 0.72, 0.9)
	home_btn.pressed.connect(_show_start)
	home_btn.pressed.connect( func() -> void : Sfx.play("click"))
	var credit: = _label("马眼工作室出品", 18, Color(WHITE, 0.62))
	_place(credit, over_screen, 0.2, 0.951, 0.8, 0.982)


	loading_screen = _make_screen()
	_color(loading_screen, NAVY, 0, 0, 1, 1)
	loading_logo = TextureRect.new()
	loading_logo.texture = load("res://assets/ui/studio-logo.jpg")
	loading_logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	loading_logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_place(loading_logo, loading_screen, 0.32, 0.31, 0.68, 0.51)
	var loading_title: = _label("舵哥快跑", 46, WHITE)
	_place(loading_title, loading_screen, 0.15, 0.54, 0.85, 0.6)
	var loading_credit: = _label("马眼工作室出品", 23, Color(WHITE, 0.7))
	_place(loading_credit, loading_screen, 0.15, 0.615, 0.85, 0.66)
	loading_bar = ProgressBar.new()
	loading_bar.show_percentage = false
	loading_bar.min_value = 0
	loading_bar.max_value = 100
	_place(loading_bar, loading_screen, 0.16, 0.71, 0.84, 0.727)
	var bar_bg: = StyleBoxFlat.new()
	bar_bg.bg_color = Color(WHITE, 0.2)
	bar_bg.set_corner_radius_all(8)
	var bar_fill: = StyleBoxFlat.new()
	bar_fill.bg_color = GOLD
	bar_fill.set_corner_radius_all(8)
	loading_bar.add_theme_stylebox_override("background", bar_bg)
	loading_bar.add_theme_stylebox_override("fill", bar_fill)

	flash = ColorRect.new()
	flash.color = Color(0.85, 0.1, 0.1, 0.0)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(flash, ui, 0, 0, 1, 1)
	update_panel = GameUpdatePanel.new()
	_build_settings()
	ui_root.add_child(update_panel)
	update_panel.setup(Updates, ui_theme)
	GameState.score_changed.connect(_on_score_changed)
	GameState.coins_changed.connect(_on_coins_changed)


func _build_settings() -> void :
	settings_screen = _make_screen()
	_color(settings_screen, Color(NAVY, 0.86), 0, 0, 1, 1)
	var card: = _panel(settings_screen, 0.075, 0.2, 0.925, 0.8, Color("102941"), 22, Color(GOLD, 0.55))
	_place(_label("设置", 46, GOLD), card, 0.1, 0.06, 0.9, 0.18)
	settings_version_label = _label("当前版本：" + Updates.installed_name, 27, WHITE)
	_place(settings_version_label, card, 0.08, 0.22, 0.92, 0.31)
	var note: = _label("更新无需卸载旧版，保留最高纪录。\n下载完成后，请在系统弹窗中确认安装。", 22, Color(WHITE, 0.78))
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_place(note, card, 0.08, 0.32, 0.92, 0.46)
	update_button = _button("检查更新", 31, NAVY, GOLD, false)
	_place(update_button, card, 0.09, 0.51, 0.91, 0.66)
	update_button.pressed.connect( func() -> void :
		update_panel.show_updates()
		Updates.check_for_updates(true))
	var close: = _button("返回游戏首页", 28, WHITE, Color("1b3854"), false)
	_place(close, card, 0.09, 0.73, 0.91, 0.88)
	close.pressed.connect(settings_screen.hide)


func _on_score_changed(v: int) -> void :
	score_label.text = _format_score(v)


func _on_coins_changed(v: int) -> void :
	coin_label.text = "◯ %d" % v


func _format_score(value: int) -> String:
	var digits: = str(value)
	var out: = ""
	while digits.length() > 3:
		out = "," + digits.substr(digits.length() - 3) + out
		digits = digits.substr(0, digits.length() - 3)
	return digits + out


func _make_screen() -> Control:
	var c: = Control.new()
	c.theme = ui_theme
	_place(c, ui_root, 0, 0, 1, 1)
	c.hide()
	return c


func _safe_ui_rect(view_size: Vector2, window: Rect2, safe: Rect2) -> Rect2:
	if window.size.x <= 0 or window.size.y <= 0 or not safe.has_area():
		return Rect2(Vector2.ZERO, view_size)
	var usable: = window.intersection(safe)
	if not usable.has_area():
		return Rect2(Vector2.ZERO, view_size)
	var scale: = view_size / window.size
	return Rect2((usable.position - window.position) * scale, usable.size * scale)


func _update_safe_area() -> void :
	if ui_root == null:
		return
	var view_size: = get_viewport().get_visible_rect().size
	var rect: = Rect2(Vector2.ZERO, view_size)
	if OS.has_feature("mobile"):
		var window: = Rect2(Vector2(DisplayServer.window_get_position()), Vector2(DisplayServer.window_get_size()))
		rect = _safe_ui_rect(view_size, window, Rect2(DisplayServer.get_display_safe_area()))


		get_viewport().scaling_3d_scale = _mobile_render_scale(window.size)
	ui_root.offset_left = rect.position.x
	ui_root.offset_top = rect.position.y
	ui_root.offset_right = rect.end.x - view_size.x
	ui_root.offset_bottom = rect.end.y - view_size.y


func _mobile_render_scale(size: Vector2) -> float:
	if size.x <= 0 or size.y <= 0:
		return 1.0
	var by_pixels: = sqrt(1000000.0 / (size.x * size.y))
	var by_edge: = 1440.0 / maxf(size.x, size.y)
	return clampf(minf(by_pixels, by_edge), 0.25, 1.0)


func _place(c: Control, parent: Node, l: float, t: float, r: float, b: float) -> void :
	parent.add_child(c)
	c.anchor_left = l
	c.anchor_top = t
	c.anchor_right = r
	c.anchor_bottom = b
	c.offset_left = 0
	c.offset_top = 0
	c.offset_right = 0
	c.offset_bottom = 0


func _color(parent: Node, color: Color, l: float, t: float, r: float, b: float) -> ColorRect:
	var c: = ColorRect.new()
	c.color = color
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(c, parent, l, t, r, b)
	return c


func _label(value: String, font_size: int, color: Color, align: = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l: = Label.new()
	l.text = value
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _panel(parent: Node, l: float, t: float, r: float, b: float, color: Color, radius: int, border: = Color.TRANSPARENT) -> Panel:
	var p: = Panel.new()
	var sb: = StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(radius)
	if border.a > 0:
		sb.set_border_width_all(2)
		sb.border_color = border
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(p, parent, l, t, r, b)
	return p


func _button(value: String, font_size: int, font_color: Color, bg: Color, raised: = true) -> Button:
	var b: = Button.new()
	b.text = value
	b.add_theme_font_size_override("font_size", font_size)
	for key in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(key, font_color)
	var sb: = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(18)
	if raised:
		sb.shadow_color = Color(NAVY, 0.35)
		sb.shadow_size = 9
		sb.shadow_offset = Vector2(0, 5)
	b.add_theme_stylebox_override("normal", sb)
	var hover: StyleBoxFlat = sb.duplicate()
	hover.bg_color = bg.lightened(0.08)
	b.add_theme_stylebox_override("hover", hover)
	var pressed: StyleBoxFlat = sb.duplicate()
	pressed.bg_color = bg.darkened(0.08)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	return b


func _build_skyline() -> void :
	var rng: = RandomNumberGenerator.new()
	rng.seed = 20261022
	for layer in 2:
		var z: = -82.0 - layer * 26.0
		var col: = Color(0.5, 0.58, 0.68) if layer == 0 else Color(0.62, 0.7, 0.79)
		var mat: = StandardMaterial3D.new()
		mat.albedo_color = col
		mat.roughness = 1.0
		for i in 15:
			var w: = rng.randf_range(7, 15)
			var h: = rng.randf_range(10, 28)
			var mi: = MeshInstance3D.new()
			var bm: = BoxMesh.new()
			bm.size = Vector3(w, h, 6)
			mi.mesh = bm
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			mi.material_override = mat
			mi.position = Vector3(-66 + i * 9.5 + rng.randf_range(-2.5, 2.5), h * 0.5 - 1.0, z + rng.randf_range(-7, 7))
			add_child(mi)



func _run_loading() -> void :
	loading_screen.show()
	_logo_t = 0.0
	var dur: = 0.1 if "--smoke" in OS.get_cmdline_user_args() else 1.35
	var tw: = create_tween()
	tw.tween_property(loading_bar, "value", 100.0, dur).from(0.0).set_ease(Tween.EASE_IN_OUT)
	tw.tween_interval(0.12)
	tw.tween_property(loading_screen, "modulate:a", 0.0, 0.35)
	tw.tween_callback( func() -> void :
		loading_screen.hide()
		_show_start())


func _run_smoke() -> void :
	print("SMOKE: start")
	get_tree().create_timer(25.0, true, false, true).timeout.connect(_smoke_timeout)
	var shot: = "--shot" in OS.get_cmdline_user_args()
	if shot:
		await get_tree().create_timer(0.8).timeout
		get_viewport().get_texture().get_image().save_png("user://shot_start.png")
	await get_tree().create_timer(0.5).timeout
	while loading_screen.visible:
		await get_tree().process_frame
	_start_game()
	var content: = 0
	for seg in track.get_children():
		for ch in seg.get_children():
			if ch.is_in_group("obstacle") or ch.is_in_group("coin"):
				content += 1
	print("SMOKE content count: ", content)
	if content < 3:
		push_error("SMOKE FAIL: no content spawned")
		get_tree().quit(1)
		return
	if shot:
		await get_tree().create_timer(3.0).timeout
		get_viewport().get_texture().get_image().save_png("user://shot_game.png")
		print("SMOKE SHOT saved")
		playing = true
		player.die()
		await get_tree().create_timer(1.8, true, false, true).timeout
		get_viewport().get_texture().get_image().save_png("user://shot_over.png")
		print("SMOKE OVER saved")
		get_tree().quit(0)
		return
	player.die()
	await get_tree().create_timer(1.5, true, false, true).timeout
	if GameState.playing or not over_screen.visible:
		push_error("SMOKE FAIL: game over flow broken")
		get_tree().quit(1)
		return
	_show_start()
	# Both the static menu and the campus 3D menu must stop gameplay at home.
	if not start_screen.visible or over_screen.visible or hud.visible or playing or GameState.playing or player.is_physics_processing() or track.is_physics_processing():
		push_error("SMOKE FAIL: home flow broken")
		get_tree().quit(1)
		return
	_start_game()
	if not GameState.playing or not player.visible or not track.visible or not hud.visible:
		push_error("SMOKE FAIL: replay flow broken")
		get_tree().quit(1)
		return
	print("SMOKE OK")
	get_tree().quit(0)


func _smoke_timeout() -> void :
	push_error("SMOKE FAIL: timeout")
	get_tree().quit(2)
