class_name CampusTrack
extends TrackManager
signal sample_finished
const SAMPLE_SECONDS: = 75.0
const SAMPLE_SPEED: = 10.0
const SAMPLE_METERS: = SAMPLE_SECONDS * SAMPLE_SPEED
const MAGNET_SCRIPT: = preload("res://scripts/campus_magnet.gd")
var completed: = false
var _road_paint: Dictionary = {}

func _ready() -> void :
	_unit_box.size = Vector3.ONE
	_rng.seed = 62109
	world_speed = SAMPLE_SPEED
	_fill()
	set_physics_process(false)

func reset() -> void :
	completed = false
	super.reset()
	world_speed = SAMPLE_SPEED

func _physics_process(delta: float) -> void :
	if completed: return
	var move: = minf(SAMPLE_SPEED * delta, SAMPLE_METERS - _distance)
	_distance += move
	world_speed = SAMPLE_SPEED
	for seg in get_children(): seg.position.z += move
	GameState.add_distance(move)
	_retire_passed_trains(delta)
	_cleanup()
	if _distance >= SAMPLE_METERS - 0.001:
		completed = true
		set_physics_process(false)
		sample_finished.emit()

func elapsed() -> float: return _distance / SAMPLE_SPEED
func zone() -> int: return mini(2, int(_distance / 250.0))
func _index(seg: Node3D) -> int: return int(floor((_distance - seg.position.z - 6.0 + 0.01) / 12.0))

func _fill() -> void :
	var far: = 24.0
	for seg in get_children(): far = minf(far, seg.position.z - 6.0)
	while far > -72.0:
		var seg: = Node3D.new()
		seg.position.z = far - 6.0
		seg.set_meta("row_index", _index(seg))
		add_child(seg)
		var visual: Node3D
		if not _visual_pool.is_empty():
			visual = _visual_pool.pop_back()
			seg.add_child(visual)
		else:
			visual = Node3D.new()
			visual.name = "StaticVisuals"
			seg.add_child(visual)
			_build_ground(visual)
			_build_scenery(visual)
			_visual_build_count += 1
		var phase: = clampi(int(maxi(0, _index(seg)) * 12.0 / 250.0), 0, 2)
		for i in 3: visual.get_node("Zone" + str(i)).visible = i == phase
		visual.get_node("Zone0/GateLandmark").visible = _index(seg) in [0, 18]
		visual.get_node("Crosswalk").visible = _index(seg) in [2, 20, 42, 60]
		_build_obstacles(seg)
		_build_coins(seg)
		far -= 12.0

func _build_ground(seg: Node3D) -> void :
	_batch_root = seg
	_ground_batches.clear()
	var body: = StaticBody3D.new()
	seg.add_child(body)
	var shape: = CollisionShape3D.new()
	var floor_box: = BoxShape3D.new()
	floor_box.size = Vector3(9.0, 0.5, 12.0)
	shape.shape = floor_box
	shape.position.y = -0.25
	body.add_child(shape)
	_box(body, Vector3(6.4, 0.45, 12), Vector3(0, -0.225, 0), Color("697d88"))
	for side in [-1.0, 1.0]:
		_box(body, Vector3(4.4, 0.3, 12), Vector3(side * 5.4, -0.03, 0), Color("d8cdb7"))
		_box(body, Vector3(0.18, 0.23, 12), Vector3(side * 3.22, 0.055, 0), Color("f0e6cd"))
		_box(body, Vector3(0.06, 0.015, 12), Vector3(side * 2.97, 0.013, 0), Color("edc46e"))
		for z in [-4.0, 0.0, 4.0]:
			_box(body, Vector3(4.2, 0.012, 0.022), Vector3(side * 5.45, 0.125, z), Color("b7af9e"))
	for x in [-1.0, 1.0]:
		for z in [-4.0, 0.0, 4.0]: _box(body, Vector3(0.075, 0.018, 1.6), Vector3(x, 0.018, z), Color("d0d6cc"))
	_flush_ground_batches()
	var cross: = MultiMeshInstance3D.new()
	cross.name = "Crosswalk"
	var multi: = MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	multi.mesh = _unit_box
	multi.instance_count = 7
	for i in 7: multi.set_instance_transform(i, Transform3D(Basis.from_scale(Vector3(0.48, 0.018, 2.3)), Vector3(-2.55 + i * 0.85, 0.035, 0)))
	cross.multimesh = multi
	cross.material_override = _road_paint[Color("d0d6cc").to_html()]
	cross.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	seg.add_child(cross)

func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, _tex: Texture2D = null, _uv: = Vector3.ONE, _unshaded: = false) -> void :
	var key: = color.to_html()
	if not _road_paint.has(key):
		var mat: = ShaderMaterial.new()
		mat.shader = CampusModels.PALETTE
		mat.set_shader_parameter("base_tint", color)
		_road_paint[key] = mat
	if not _ground_batches.has(key): _ground_batches[key] = {"material": _road_paint[key], "transforms": []}
	_ground_batches[key].transforms.append(_batch_root.global_transform.affine_inverse() * parent.global_transform * Transform3D(Basis.from_scale(size), pos))

func _place_model(parent: Node3D, kind: String, at: Vector3, turn: = 0.0) -> Node3D:
	var model: = CampusModels.make(kind)
	parent.add_child(model)
	model.position = at
	model.rotation.y = turn
	return model

func _build_scenery(seg: Node3D) -> void :
	var variant: = _visual_build_count % 4
	for phase in 3:
		var root: = Node3D.new()
		root.name = "Zone" + str(phase)
		seg.add_child(root)
		for side in [-1.0, 1.0]:
			var kind: String = ["school", "store", "cafe", "books"][(variant + int(side + 1)) % 4]
			if phase == 0: kind = "school" if side < 0 else ["books", "school"][variant % 2]
			elif phase == 1: kind = ["store", "cafe", "books"][(variant + int(side + 1)) % 3]
			elif phase == 2 and side > 0: kind = "bus_stop"
			var x: = 5.95 if kind != "bus_stop" else 5.35
			_place_model(root, kind, Vector3(side * x, 0.1, -1.8), side * -0.12)
			var tree: = _place_model(root, "tree", Vector3(side * 3.72, 0.13, 4.3))
			tree.scale = Vector3.ONE * 0.75
			if variant % 2 == 0: _place_model(root, "bench", Vector3(side * 3.65, 0.13, 0.3), side * PI / 2)
		if phase == 0:
			var gate: = _place_model(root, "gate", Vector3(-5.7, 0.1, 4.3))
			gate.name = "GateLandmark"
		if phase == 2 and variant == 2: _place_model(root, "bus", Vector3(-5.3, 0.13, 0))

static func pattern(index: int) -> Dictionary:
	var row: = _base_pattern(index)

	if index >= 25 and index < 37 or index >= 50:
		for hazard in row.hazards: hazard[1] *= -1
		for route in row.routes: route[0] *= -1
	if index in [16, 45]:
		row = _row(0, 5)
		row.magnet = true
	return row

static func _base_pattern(index: int) -> Dictionary:

	if index < 0 or index >= 62: return _row(0, 0)
	if index < 13:
		match index:
			0, 1, 6, 12: return _row(0, 5)
			3: return _row(-1, 5)
			4: return _row(-1, 4, [["parcel", -1]], "jump")
			7: return _row(0, 4, [["slide", 0]], "slide")
			9: return _row(1, 5)
			10: return _row(1, 4, [["barrier", 1]], "jump")
			_: return _row(0, 0)
	if index < 38:
		match (index - 13) % 12:
			0: return _row(0, 5, [["bus", -1]])
			1: return _row(0, 4, [["parcel", 0]], "jump")
			2: return _row(1, 4, [["slide", 1]], "slide")
			3, 11: return _row(0, 0)
			4: return _row(0, 5, [["bus", 1]])
			5: return _row(-1, 4, [["barrier", -1], ["parcel", 1]], "jump")
			6: return _row(0, 4, [["slide", 0]], "slide")
			7: return _row(1, 5, [["bus", 0]])
			8: return _row(1, 4, [["parcel", 1]], "jump")
			9: return _row(0, 5, [["slide", -1]])
			_: return _row(-1, 4, [["slide", -1]], "slide")
	match (index - 38) % 12:
		0: return _row(0, 4, [["parcel", 0], ["bus", -1]], "jump")
		1: return _row(1, 4, [["slide", 1], ["barrier", -1]], "slide")
		2: return _row(0, 4, [["barrier", 0], ["bus", 1]], "jump")
		3: return _row(0, 0, [["bus", -1]])
		4: return _row(-1, 4, [["slide", -1], ["parcel", 1]], "slide")
		5: return _row(0, 4, [["parcel", 0], ["bus", -1]], "jump")
		6: return _row(1, 4, [["barrier", 1], ["slide", 0]], "jump")
		7, 11: return _row(0, 0)
		8: return _row(0, 4, [["slide", 0], ["bus", 1]], "slide")
		9: return _row(-1, 4, [["parcel", -1], ["barrier", 1]], "jump")
		_: return _row(0, 5, [["bus", -1]])

static func _row(lane: int, count: int, hazards: Array = [], action: = "") -> Dictionary:
	return {"hazards": hazards, "routes": [[lane, count, 0.65 if action == "slide" else 1.0]] if count > 0 else [], "action": action, "magnet": false}

func _build_obstacles(seg: Node3D) -> void :
	var row: = pattern(_index(seg))
	for hazard in row.hazards:
		var area: = CampusModels.obstacle(hazard[0])
		seg.add_child(area)
		area.position.x = hazard[1] * 2.0
	if row.get("magnet", false):
		var pickup = MAGNET_SCRIPT.new()
		pickup.position = Vector3(0, 1.1, 0)
		seg.add_child(pickup)

func _build_coins(seg: Node3D) -> void :
	var row: = pattern(_index(seg))
	for route in row.routes:
		for i in int(route[1]):
			var coin: = Coin.new()
			coin.campus_style = true
			var progress: = float(i) / maxf(1, float(route[1]) - 1)
			var height: float = route[2]


			if row.action == "jump": height += sin(progress * PI) * 1.9
			coin.position = Vector3(route[0] * 2.0, height, lerpf(-3.6, 3.6, progress))
			seg.add_child(coin)
