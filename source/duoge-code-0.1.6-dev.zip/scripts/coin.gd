class_name Coin
extends Area3D


var _t: = 0.0
var _base_y: = 0.0
var _collected: = false
var _mesh: Node3D
var _attraction_target: Node3D
var campus_style: = false
static var _shared_mesh: CylinderMesh
static var _shared_material: StandardMaterial3D
static var _shared_shape: SphereShape3D


func _ready() -> void :
	add_to_group("coin")
	collision_layer = 2
	collision_mask = 0
	_base_y = position.y
	if _shared_mesh == null:
		_shared_mesh = CylinderMesh.new()
		_shared_mesh.top_radius = 0.4
		_shared_mesh.bottom_radius = 0.4
		_shared_mesh.height = 0.1
		_shared_mesh.radial_segments = 16
		_shared_material = StandardMaterial3D.new()
		_shared_material.albedo_color = Color(1.0, 0.84, 0.15)
		_shared_material.diffuse_mode = BaseMaterial3D.DIFFUSE_TOON
		_shared_material.roughness = 0.35
		_shared_material.metallic = 0.4
		_shared_material.emission_enabled = true
		_shared_material.emission = Color(1.0, 0.75, 0.1)
		_shared_material.emission_energy_multiplier = 1.6
		_shared_shape = SphereShape3D.new()
		_shared_shape.radius = 0.55
	if campus_style:
		_mesh = CampusModels.make("coin")
	else:
		var standard: = MeshInstance3D.new()
		standard.mesh = _shared_mesh
		standard.material_override = _shared_material
		standard.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		standard.rotation_degrees = Vector3(90, 0, 0)
		_mesh = standard
	add_child(_mesh)
	var cs: = CollisionShape3D.new()
	cs.shape = _shared_shape
	add_child(cs)


func _process(delta: float) -> void :
	if _collected:
		return
	if campus_style and global_position.z > 1.25 and not is_instance_valid(_attraction_target):
		queue_free()
		return
	_t += delta
	rotate_y(3.2 * delta)
	if is_instance_valid(_attraction_target):
		var target: = _attraction_target.global_position + Vector3(0, 0.85, 0)
		global_position = global_position.move_toward(target, 24.0 * delta)
		if global_position.distance_squared_to(target) < 0.16:
			try_collect()
	else:
		position.y = _base_y + sin(_t * 3.0) * 0.09


func attract_to(target: Node3D) -> void :
	if not _collected:
		_attraction_target = target


func try_collect() -> void :
	if _collected:
		return

	collect()
	GameState.collect_coin()


func collect() -> void :
	if _collected:
		return
	_collected = true
	Sfx.play("coin", -5.0)
	set_deferred("monitorable", false)
	set_deferred("monitoring", false)
	if campus_style: _mesh.hide()

	var lbl: = Label3D.new()
	lbl.text = "+10"
	lbl.font_size = 88 if campus_style else 220
	lbl.pixel_size = 0.0018 if campus_style else 0.0028
	lbl.modulate = Color(1.0, 0.85, 0.2)
	lbl.outline_size = 10 if campus_style else 44
	lbl.outline_modulate = Color(0.3, 0.18, 0.0)
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	var feedback_parent: Node = get_parent()
	if campus_style and get_tree().current_scene: feedback_parent = get_tree().current_scene
	feedback_parent.add_child(lbl)
	lbl.global_position = global_position + Vector3(0, 0.5, 0)

	var tw: = lbl.create_tween()
	tw.set_parallel(true)
	tw.tween_property(lbl, "position:y", lbl.position.y + 0.8, 0.45).set_ease(Tween.EASE_OUT)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.45).set_ease(Tween.EASE_IN)
	tw.chain().tween_callback(lbl.queue_free)

	var tw2: = create_tween()
	tw2.set_parallel(true)
	tw2.tween_property(_mesh, "scale", 2.0 * Vector3.ONE, 0.12).set_ease(Tween.EASE_OUT)
	tw2.tween_property(self, "position:y", _base_y + 0.35, 0.12).set_ease(Tween.EASE_OUT)
	tw2.chain().tween_callback(queue_free)
