extends Node3D




var player: Player
var _view: = "rear"


func _ready() -> void :
	var args: = OS.get_cmdline_user_args()
	if "--side" in args:
		_view = "side"
	elif "--front" in args:
		_view = "front"
	var environment: = WorldEnvironment.new()
	var env: = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.65, 0.72, 0.77)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color.WHITE
	env.ambient_light_energy = 0.75
	environment.environment = env
	add_child(environment)
	var sun: = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45.0, -30.0, 0.0)
	sun.light_energy = 1.2
	add_child(sun)
	var floor: = StaticBody3D.new()
	var collision: = CollisionShape3D.new()
	var box: = BoxShape3D.new()
	box.size = Vector3(12.0, 0.2, 12.0)
	collision.shape = box
	collision.position.y = -0.1
	floor.add_child(collision)
	var surface: = MeshInstance3D.new()
	var plane: = PlaneMesh.new()
	plane.size = Vector2(12.0, 12.0)
	surface.mesh = plane
	var material: = StandardMaterial3D.new()
	material.albedo_color = Color(0.28, 0.32, 0.35)
	material.roughness = 1.0
	surface.material_override = material
	floor.add_child(surface)
	add_child(floor)
	player = (load("res://scenes/player.tscn") as PackedScene).instantiate()
	player.position = Vector3(0.0, Player.GROUND_Y, 0.0)
	player.run_speed = 8.0
	add_child(player)
	var camera: = Camera3D.new()
	camera.fov = 45.0
	camera.position = Vector3(0.0, 1.4, 4.0)
	if _view == "side":
		camera.position = Vector3(4.0, 1.25, 0.0)
	elif _view == "front":
		camera.position = Vector3(0.0, 1.4, -4.0)
	add_child(camera)
	camera.look_at(Vector3(0.0, 0.95, 0.0), Vector3.UP)
	camera.make_current()
	if "--shot" in args:
		_capture_cycle()


func _capture_cycle() -> void :
	await get_tree().create_timer(1.0).timeout
	if player._animation_player == null or not player.is_on_floor() or player._current_clip != "Run":
		push_error("RUNNER PREVIEW: new model did not enter grounded Run animation")
		get_tree().quit(1)
		return
	var clip: = player._animation_player.get_animation(player._animation_names["Run"])
	var step: = clip.length / 8.0
	DirAccess.make_dir_recursive_absolute("user://runner_preview")
	for i in 8:
		await RenderingServer.frame_post_draw
		var path: = "user://runner_preview/%s_%02d.png" % [_view, i]
		var error: = get_viewport().get_texture().get_image().save_png(path)
		if error != OK:
			push_error("RUNNER PREVIEW: could not save " + path)
			get_tree().quit(2)
			return
		await get_tree().create_timer(step).timeout
	print("RUNNER PREVIEW OK: ", _view, " 8 frames")
	get_tree().quit(0)
